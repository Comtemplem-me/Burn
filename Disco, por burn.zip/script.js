const dados = [
    {
        "user": "dyy_die",
        "mensagem": "A partir de hoje esse é o novo atumalaka",
        "data": "14:44 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Acho que fui um pouco exagerado",
        "data": "14:44 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "F tudo",
        "data": "15:02 de 09/01/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Vdd",
        "data": "15:02 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu já tenho um server pronto pra zueira²",
        "data": "15:02 de 09/01/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Manda",
        "data": "15:02 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "https://discord.com/invite/VhrSfPn6",
        "data": "15:03 de 09/01/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "<@647798629641224192>",
        "data": "15:06 de 09/01/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "<@647798629641224192>",
        "data": "15:07 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@674267691627839510>",
        "data": "15:07 de 09/01/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "<@647798629641224192>",
        "data": "15:07 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vó te ensinar o bug no cll",
        "data": "15:07 de 09/01/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Eu n",
        "data": "15:07 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rlx",
        "data": "15:07 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vai em",
        "data": "15:07 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Notificação",
        "data": "15:07 de 09/01/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds",
        "data": "15:07 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E clica na primeira mensagem q tu foi mencionado aq",
        "data": "15:07 de 09/01/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Plmds",
        "data": "15:07 de 09/01/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "A já volto",
        "data": "15:07 de 09/01/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Deletou tudo ainda por cima",
        "data": "15:07 de 09/01/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Entra no novo Server ai",
        "data": "15:07 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Obc",
        "data": "15:08 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Obv",
        "data": "15:08 de 09/01/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hehe",
        "data": "15:08 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "É o resetamento",
        "data": "15:08 de 09/01/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Pedra é o made in heaven",
        "data": "15:08 de 09/01/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nah",
        "data": "15:08 de 09/01/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Se pedra fez",
        "data": "15:08 de 09/01/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Então",
        "data": "15:08 de 09/01/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Adios",
        "data": "15:08 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd edu",
        "data": "15:10 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bruna tá puta ein",
        "data": "15:10 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Se não era pra eu criar",
        "data": "15:10 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ent quem seria",
        "data": "15:10 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Meu fi tu vai ficar aí na sólida",
        "data": "15:10 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Talvez",
        "data": "15:10 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Solidão*",
        "data": "15:10 de 09/01/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Acho q ele já é solido",
        "data": "15:11 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sólido",
        "data": "15:13 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ele tá bem sólido",
        "data": "17:33 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tão sólido q saiu de grupo",
        "data": "17:33 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mas n saiu do server",
        "data": "17:33 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ou talvez saiu",
        "data": "17:33 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Que papo é esse?",
        "data": "17:33 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ces deleto os mais de 10k que o burn havia mandado?",
        "data": "17:34 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Então..",
        "data": "17:34 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Pera",
        "data": "17:35 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Apagamos o server inté",
        "data": "17:35 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "VOCES TIRARAM TUDO?!",
        "data": "17:35 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "OQUE",
        "data": "17:35 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sim....",
        "data": "17:35 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Essa é a fase",
        "data": "17:35 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "MAS QUE MERDA VOCES TAVA NA CABEÇA",
        "data": "17:35 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "A era",
        "data": "17:35 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Que acabou",
        "data": "17:35 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "FASE? ERA?",
        "data": "17:35 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sim",
        "data": "17:35 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ent me diz qual nome da era que agora tá morta :/",
        "data": "17:35 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Edu concordou em tudo",
        "data": "17:35 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "A era da pedra",
        "data": "17:35 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Agora chegou Novamente",
        "data": "17:36 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "'_'",
        "data": "17:36 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Nova era chamada pedra",
        "data": "17:36 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Longa história",
        "data": "17:36 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mas o edu concordou em tudo",
        "data": "17:36 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "'_'",
        "data": "17:36 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ce obrigo ele a concorda né pedra?",
        "data": "17:36 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Nop",
        "data": "17:36 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ele concordou em tudo",
        "data": "17:36 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Infelizmente é um acontecimento",
        "data": "17:37 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Até parece que você é o presidente e o edu só concorda com tudo que tu diz ne",
        "data": "17:37 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Acontecimento esse que vai ser esquecido daqui em 1 dia",
        "data": "17:37 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu disse,\"que tu acha edu de eu apagar tudo\". Ele:vdd",
        "data": "17:37 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Aí dnv",
        "data": "17:38 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "\"que tu acha de eu mandar um outro server\"Ele: manda",
        "data": "17:38 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ainda me chamou de made in heaven",
        "data": "17:38 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "What fuck",
        "data": "17:38 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "O edu cheiro azulzinha",
        "data": "17:39 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Não foi exatamente isso q eu disse mas foi mais ou menos isso",
        "data": "17:39 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Aí a Bruna ficou puta pq fui eu q criei o server",
        "data": "17:39 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Dps ele saiu de todos os grupos",
        "data": "17:39 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Eu vi aqui",
        "data": "17:39 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E desse server",
        "data": "17:39 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "C acredita q a Bruna disse palavras",
        "data": "17:40 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Aquelas mermo",
        "data": "17:40 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ele disse \"fds\" pra oque acontecer dps",
        "data": "17:40 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ou algo assim",
        "data": "17:40 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tá lá encima",
        "data": "17:40 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Na vdd nn",
        "data": "17:40 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tá no atumalaka morto",
        "data": "17:40 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "'-'",
        "data": "17:41 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Nossa",
        "data": "17:41 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Faz quantos dias que eu fiquei fora?",
        "data": "17:41 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Acho que 1 semana pra essa caralhada de coisa acontecer",
        "data": "17:41 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ma rapaiz",
        "data": "17:41 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Foi hoje",
        "data": "17:41 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "burn não conseguiu nem esconder a sua raiva",
        "data": "17:41 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tudo isso por causa de mensagens",
        "data": "17:41 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Jaq pra ele era bem impo",
        "data": "17:42 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Importante",
        "data": "17:42 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Aí eu e o edu fez uma parceria",
        "data": "17:42 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ele disse q se ele me desse adm eu teria q apagar 10k de mensagens da bruna",
        "data": "17:42 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Aí eu dei um troll nele",
        "data": "17:42 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Dps eu apaguei tudo",
        "data": "17:42 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Literalmente",
        "data": "17:43 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Cara",
        "data": "17:43 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Tu é muito apocalíptico sério",
        "data": "17:43 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Foi culpa de todos",
        "data": "17:43 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Exceto eu",
        "data": "17:43 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "A pera",
        "data": "17:43 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tu n",
        "data": "17:43 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Aquele grupo?",
        "data": "17:43 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Qual",
        "data": "17:44 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "O culpa de todos?",
        "data": "17:44 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Foi culpa do grupo culpa de todos?",
        "data": "17:44 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Fala com ele ai",
        "data": "17:44 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pergunta que aconteceu",
        "data": "17:44 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pra ele n desconfiar",
        "data": "17:44 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ok",
        "data": "17:44 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ele respondeu?",
        "data": "17:47 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Nada",
        "data": "17:47 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Acho que ele vai fica um bom tempo off",
        "data": "17:47 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ele vai virar tu",
        "data": "17:47 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Credo",
        "data": "17:48 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Que ele seja ele mesmo",
        "data": "17:48 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Seja eu não",
        "data": "17:48 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vdd",
        "data": "17:48 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vai fica 1 semana com estresse psicológico",
        "data": "17:48 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Mas vey aqueles 10k de mensagem do burn a maioria nem era tão importante assim",
        "data": "17:49 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Namoral são mensagem",
        "data": "17:51 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ele ficou reclamando pq tem \"história\"",
        "data": "17:51 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Aí eu dei um argumento a ele dizendo:\"tipo mensagens repetidas q todo mundo já disse?\"",
        "data": "17:52 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vdd",
        "data": "17:52 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Então,agora o novo server e o anti regras",
        "data": "17:52 de 09/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ok",
        "data": "18:33 de 09/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Perai",
        "data": "12:59 de 11/01/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Tô peraindo",
        "data": "18:02 de 12/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Perou dms",
        "data": "15:55 de 17/01/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Balde é gay",
        "data": "17:48 de 26/02/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "pedra fuma paiol",
        "data": "17:53 de 26/02/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Paiol é pólvora bro",
        "data": "18:04 de 26/02/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tá loco?",
        "data": "18:04 de 26/02/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vlt",
        "data": "18:05 de 26/02/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Bora?",
        "data": "18:05 de 26/02/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu te vi na sexta passada com uma caixa de Malboro no bolso",
        "data": "18:05 de 26/02/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bora",
        "data": "18:05 de 26/02/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Calme",
        "data": "18:05 de 26/02/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Real",
        "data": "18:05 de 26/02/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Boto pressão em mim k",
        "data": "18:05 de 26/02/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Godenot tá muito pilantra",
        "data": "18:06 de 26/02/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Caraca",
        "data": "18:09 de 26/02/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu vi o burn nesse local aí girando numa vara de ferro",
        "data": "18:09 de 26/02/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Confia",
        "data": "18:09 de 26/02/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Real",
        "data": "18:12 de 26/02/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Vdd",
        "data": "10:04 de 28/02/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Acho q eu deveria deixar o antigo chat principal",
        "data": "23:00 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Assim n sumia as melhores mensagens",
        "data": "23:00 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Agora foi tarde",
        "data": "23:00 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E tbm me arrependo disso",
        "data": "23:00 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "🤔",
        "data": "23:05 de 30/03/2024"
    },
    {
        "user": "UnbelievaBoat#1046",
        "mensagem": "",
        "data": "23:05 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Caraca",
        "data": "23:06 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Genial",
        "data": "23:06 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Quem criou isso?",
        "data": "23:06 de 30/03/2024"
    },
    {
        "user": "Soccer Guru#6185",
        "mensagem": "",
        "data": "23:06 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Q",
        "data": "23:06 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": ".store",
        "data": "23:06 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "! store",
        "data": "23:06 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": ";store",
        "data": "23:06 de 30/03/2024"
    },
    {
        "user": "UnbelievaBoat#1046",
        "mensagem": "",
        "data": "23:06 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": ";buy mae do idro",
        "data": "23:07 de 30/03/2024"
    },
    {
        "user": "UnbelievaBoat#1046",
        "mensagem": "",
        "data": "23:07 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Nah",
        "data": "23:07 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Agora q lembrei q apaguei até os cargos",
        "data": "23:08 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Culpa do edu",
        "data": "23:08 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ele concordou com tudo",
        "data": "23:08 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu só segui",
        "data": "23:08 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vó tentar fazer o server dnv",
        "data": "23:11 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Amanhã",
        "data": "23:14 de 30/03/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "!exemplo",
        "data": "23:40 de 10/04/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Droga",
        "data": "23:40 de 10/04/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Pedra tá se envolvendo em tráfico de drogas",
        "data": "22:32 de 12/04/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu uso droga zumbi,so nao vendo",
        "data": "14:11 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Que isso",
        "data": "14:12 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Pedra?",
        "data": "14:12 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Onde você tava cara",
        "data": "14:12 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Aqui",
        "data": "14:12 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Eu liguei pra ti mas você simplesmente me bloqueou",
        "data": "14:12 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Desbloqueado",
        "data": "14:12 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Foram poucos dias",
        "data": "14:13 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Cara",
        "data": "14:13 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Foi 1 mês",
        "data": "14:13 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pouco",
        "data": "14:13 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": ":/",
        "data": "14:13 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Oque tu tava fazendo nesse tempo de 1 mês?",
        "data": "14:13 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Literalmente lembrei hoje que tu tava bloqueado",
        "data": "14:13 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Usando discord",
        "data": "14:13 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Conheci novas pessoas",
        "data": "14:14 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Manda add no roblox",
        "data": "14:14 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ata",
        "data": "14:14 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tive também muitas viagens",
        "data": "14:14 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E aventuras",
        "data": "14:14 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Boa",
        "data": "14:15 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Te mandei add",
        "data": "14:15 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vou comer pudim agora",
        "data": "14:15 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ta",
        "data": "14:16 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Você não mandou",
        "data": "14:24 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Mandei",
        "data": "14:25 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "É sério",
        "data": "14:25 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Você que não viu direito",
        "data": "14:25 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Você ta botando pobre né",
        "data": "14:27 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "O cara não lembra meu nick",
        "data": "14:27 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Nop",
        "data": "14:27 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Tô botando seu nick",
        "data": "14:27 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "De vdd",
        "data": "14:27 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "pedrovitormotah240",
        "data": "14:27 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Esse aí",
        "data": "14:27 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "O cara não lembra nem o próprio nick",
        "data": "14:27 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Não está mostrando nada",
        "data": "14:28 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vou manda pra tu",
        "data": "14:28 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ok",
        "data": "14:28 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "IdroBilu_1GD",
        "data": "14:29 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Né",
        "data": "14:29 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Isso",
        "data": "14:29 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mandei",
        "data": "14:30 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Não liga pra nick",
        "data": "14:30 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "A amizade já está formada",
        "data": "14:30 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Não estava",
        "data": "14:31 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Que jeito mais sem graça de dizer que você fez um amigo",
        "data": "14:31 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Credo",
        "data": "14:31 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Agora esta",
        "data": "14:31 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ótimo comunista",
        "data": "14:31 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sim",
        "data": "14:31 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Você sabia",
        "data": "14:32 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Que sabia",
        "data": "14:32 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "",
        "data": "14:33 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Que ele não sabia",
        "data": "14:33 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Foda",
        "data": "14:33 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "",
        "data": "14:34 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ao mosso",
        "data": "14:34 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Real",
        "data": "14:34 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "",
        "data": "14:35 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sei nem qual é esse",
        "data": "14:35 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ata",
        "data": "14:35 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "So mandei",
        "data": "14:35 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Tendi nada",
        "data": "14:35 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Estudar igual um condenado",
        "data": "14:35 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Só um pouco",
        "data": "14:35 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Essa parte tendi",
        "data": "14:35 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pra chutar o próprio nome",
        "data": "14:35 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ata",
        "data": "14:36 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vdd",
        "data": "14:36 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sim",
        "data": "14:36 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Quer ir tsb?",
        "data": "14:37 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Treasure?",
        "data": "14:38 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Não",
        "data": "14:38 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Sei oque não é pedra",
        "data": "14:38 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "The strongest battlegrounds",
        "data": "14:38 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "a",
        "data": "14:38 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Já joguei mas não gostei muito não",
        "data": "14:39 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tá",
        "data": "14:39 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "a dusty road trip",
        "data": "14:40 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?",
        "data": "14:40 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Dusty road trip?",
        "data": "14:41 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Se for coisa de puteiro eu vou",
        "data": "14:41 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "a dusty road trip",
        "data": "14:41 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Literalmente o nome tá dizendo,\"uma viagem empoeirada\". É sobre viagem,e deserto",
        "data": "14:42 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ata",
        "data": "14:42 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Já joguei",
        "data": "14:42 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pelo visto você não sabe inglês",
        "data": "14:42 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "É legal",
        "data": "14:42 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu acho",
        "data": "14:42 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vamo?",
        "data": "14:42 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "È que eu não sabia o significado de dusty e trip",
        "data": "14:42 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Mas enfim",
        "data": "14:42 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "To dentro",
        "data": "14:42 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sabe o mapa de cs",
        "data": "14:42 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Dust",
        "data": "14:42 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Hm",
        "data": "14:42 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "É o mesmo significado",
        "data": "14:43 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Dust",
        "data": "14:43 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E dusty",
        "data": "14:43 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Dusty é a pronúncia certa,no sentido inglês",
        "data": "14:43 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Dust é tipo uma abreviação",
        "data": "14:43 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tipo",
        "data": "14:43 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Lol",
        "data": "14:43 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Idk",
        "data": "14:43 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Idc",
        "data": "14:43 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sabe",
        "data": "14:43 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Soq sem encolher muito a palavra",
        "data": "14:43 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ata",
        "data": "14:44 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Agora vamo",
        "data": "14:44 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ok",
        "data": "14:44 de 01/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Legal que os cara gasta 1 milésimo da sua vida só pra tirar uma única letra k",
        "data": "14:44 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Q",
        "data": "18:06 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Que lanche mais demorado",
        "data": "18:08 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "18:08 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "18:10 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<#1194335733054443571>",
        "data": "18:14 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Balde?",
        "data": "18:58 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "19:43 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "19:57 de 01/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "19:58 de 01/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Q lanchão em",
        "data": "09:46 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Verdade",
        "data": "18:30 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Qual o café da manhã?",
        "data": "18:30 de 03/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Pão com cimento",
        "data": "18:42 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Caralho",
        "data": "18:43 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "O balde é o bitelo",
        "data": "18:43 de 03/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Burn tá se infiltrando em coisas adultas",
        "data": "18:46 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Como",
        "data": "19:42 de 03/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Recomendações",
        "data": "19:43 de 03/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Acho que o burn tá chegando naquela fase pedra",
        "data": "19:43 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Convida ele ai",
        "data": "19:44 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Balde",
        "data": "19:45 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Que tal nois recontruir o server",
        "data": "19:45 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Reconstruir*",
        "data": "19:45 de 03/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Aquele lá estrago?",
        "data": "19:47 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Se tu perceber",
        "data": "19:48 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Acho q sim",
        "data": "19:48 de 03/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Hmmmm",
        "data": "19:48 de 03/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ok",
        "data": "19:48 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Além de q aquí e como o últimos anos",
        "data": "19:48 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pode reconstruir do jeito q quiser",
        "data": "19:49 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Chama a bruna ai",
        "data": "19:49 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pra ajudar",
        "data": "19:49 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "✌️",
        "data": "19:49 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Paz e amor",
        "data": "19:49 de 03/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ok",
        "data": "19:49 de 03/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "12:43 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@674267691627839510>",
        "data": "12:43 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@880817605772967946>",
        "data": "12:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "12:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@674267691627839510>",
        "data": "12:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@880817605772967946>",
        "data": "12:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "12:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@674267691627839510>",
        "data": "12:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@880817605772967946>",
        "data": "12:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "12:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@674267691627839510>",
        "data": "12:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@880817605772967946>",
        "data": "12:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "12:44 de 04/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vou almoçar",
        "data": "12:49 de 04/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "O pedra",
        "data": "12:55 de 04/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Que história é essa de ter 8 regras aqui em",
        "data": "12:55 de 04/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Nunca soube que tinha regras aqui",
        "data": "12:55 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "12:56 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "adorei como me descreveram k",
        "data": "12:57 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "como seis adicionaram meu bot k",
        "data": "12:57 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera não é bot",
        "data": "12:57 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "genius",
        "data": "12:57 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "app?",
        "data": "12:58 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "caraca to veio",
        "data": "12:58 de 04/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Boa",
        "data": "12:59 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "um dia ele acorda k",
        "data": "12:59 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "q",
        "data": "12:59 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "é vdd",
        "data": "12:59 de 04/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vdd",
        "data": "12:59 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "agora bruna",
        "data": "12:59 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "now?",
        "data": "12:59 de 04/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Tá de ressaca",
        "data": "13:00 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pq tu apagou minha Bíblia??",
        "data": "13:00 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "13:00 de 04/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vish",
        "data": "13:00 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nada n",
        "data": "13:00 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ce acha q eu não esqueci ne",
        "data": "13:00 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx q rlx",
        "data": "13:00 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "server ficou calado do nada",
        "data": "13:00 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "veja a rlx que tá mais fácil kk",
        "data": "13:00 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "nah",
        "data": "13:01 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd?",
        "data": "13:01 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Quando isso vadio",
        "data": "13:01 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "oia aqui",
        "data": "13:01 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "13:01 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "N fui eu",
        "data": "13:01 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Foi tu q criou isso",
        "data": "13:01 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quem será",
        "data": "13:01 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Você",
        "data": "13:02 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu lembro",
        "data": "13:02 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "memória em",
        "data": "13:02 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nem eu lembrava k",
        "data": "13:02 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ce não,mas eu sim",
        "data": "13:02 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah",
        "data": "13:02 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu descobri bem facil pq tu usa \" >) \"",
        "data": "13:03 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pq será?",
        "data": "13:03 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "idk",
        "data": "13:03 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "claramente peguei de alguém",
        "data": "13:03 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho q no em",
        "data": "13:03 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Além disso está mencionando a si mesmo",
        "data": "13:03 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "13:03 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "a",
        "data": "13:03 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa pedra",
        "data": "13:04 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bem impressionante q você digitou isso",
        "data": "13:04 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tão especificamente",
        "data": "13:04 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "13:04 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdddddddd",
        "data": "13:04 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Gostei muito da 7 não",
        "data": "13:04 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Não curto ser chamado de pedro",
        "data": "13:04 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aham",
        "data": "13:04 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Prefiro pelo meu segundo nome",
        "data": "13:04 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vitor",
        "data": "13:04 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "13:04 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "então ainda prefiro pedra em",
        "data": "13:05 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "faz 2 milênios q alguém me chama de pedra",
        "data": "13:05 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa tá novo o negocio de bot aq",
        "data": "13:05 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Soube eu não",
        "data": "13:05 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa eu uso 10000000000000000000% das vezes",
        "data": "13:05 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "poucos 0",
        "data": "13:05 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "13:05 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "a quantidade de bot q tem nesse server eu acho pouco",
        "data": "13:06 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "bora adicionar mais",
        "data": "13:06 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?",
        "data": "13:06 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa",
        "data": "13:06 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "13:06 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "hehe",
        "data": "13:06 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vou usar o top gg",
        "data": "13:06 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mais de 50 em",
        "data": "13:06 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "internet top",
        "data": "13:06 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "bora botar uns 30 a mais",
        "data": "13:06 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que tem ele ainda lá?",
        "data": "13:07 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "o terror da pedra",
        "data": "13:07 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkkk",
        "data": "13:07 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "13:07 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tem como adicionar ele aq?",
        "data": "13:08 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rap",
        "data": "13:08 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa*",
        "data": "13:08 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa quero ver ele me entender hehe",
        "data": "13:09 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa",
        "data": "13:09 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "perfect how adicionar bot estando sem poder",
        "data": "13:10 de 04/05/2024"
    },
    {
        "user": "Phasmochecker#3961",
        "mensagem": "",
        "data": "13:10 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "13:10 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "phasmo?",
        "data": "13:11 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "phasmofobia?",
        "data": "13:11 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0000000000000000",
        "data": "13:11 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "13:11 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acorda ae dorminhoco",
        "data": "13:11 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds quantos",
        "data": "13:11 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bruna",
        "data": "13:11 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm?",
        "data": "13:11 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sabe o epic rpg",
        "data": "13:11 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu fiz a edge",
        "data": "13:11 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Edgy",
        "data": "13:11 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "13:11 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sei la",
        "data": "13:11 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Nem lembro mais",
        "data": "13:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "A armadura",
        "data": "13:12 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nem eu lembro mais how joga",
        "data": "13:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Que tal nois ir dungeon?",
        "data": "13:12 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera que tá voltando as memórias",
        "data": "13:12 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "lembrei",
        "data": "13:12 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "13:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Chama o bot ai",
        "data": "13:12 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tenta oce ae",
        "data": "13:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ok",
        "data": "13:12 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pensei 3 formas diferentes para pegar a do edu k",
        "data": "13:13 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "isso anta fala em público",
        "data": "13:13 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa",
        "data": "13:13 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ctz que sei guardar segredo",
        "data": "13:13 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ae",
        "data": "13:13 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "13:13 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@647798629641224192>, welcome back to EPIC RPG! 🎉🎉 Seems like you have been inactive for a while, here is an event to celebrate your returning: `/returning`",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Oque do edu?",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nada n",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pera...",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx que eu não copio ngn",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Rlx",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "EU PERDI MEU RETURNING",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mds",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "boa",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sou mo burro",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg rd",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdddddddd",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg ret",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@880817605772967946>, this event is only available for players that have been inactive for over 2 months",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Perdi",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "over?",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Nah",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg profile <@647798629641224192>",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ta pobre",
        "data": "13:15 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg profile",
        "data": "13:15 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:15 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aprendi a traduzir diretamente do discord k",
        "data": "13:15 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Uau",
        "data": "13:15 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu tenho uma extension pra issi",
        "data": "13:15 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q pobre oq",
        "data": "13:15 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "serious?",
        "data": "13:15 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu recomendo você usar as extension",
        "data": "13:15 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Elas ajuda dms",
        "data": "13:15 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "eu uso o tradutor do navegador k",
        "data": "13:15 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkkkkkkkk",
        "data": "13:15 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:15 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "pera",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ja comprou a key?",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nem tenho dinheiro acho",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg inventory <@647798629641224192>",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que dá alguma coisa isso?",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "poca coisa",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Comprou n",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ce tem 145 rubi",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pq tenho 136 bananas",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Slk",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu tenho mais bananas",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Hehe",
        "data": "13:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg inventory",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa q duplo",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu acho",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu tenho",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "poca mdeira",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu usei dismantle em todas",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "boa",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aprendeu do mestre obvius",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hehe",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ne não",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera q q tem o returning?",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0000000000000000000000",
        "data": "13:17 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ele tira 33% do seu tempo de recarga",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Em tudo",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Literalmente tudo",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ele te da mais xp",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eeeeeeeee",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Moedas",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tem o shop",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu amei esse banner",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pedra pablo ricasso k",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkkkkkkkkkkk",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Faz sentido a todos nós",
        "data": "13:18 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "13:19 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:19 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu acho q n comprei a key da dungeon",
        "data": "13:19 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:19 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg dungeon <@647798629641224192>",
        "data": "13:19 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:19 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "q",
        "data": "13:19 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "k",
        "data": "13:19 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg dungeon <@647798629641224192>",
        "data": "13:19 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "quem será",
        "data": "13:19 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg buy dungeon Key",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "You don't have enough money to buy this",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ctz que acha que nois vence?",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vence pow",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Lembra q eu matava eles com 1 hut",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Hit",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "KKK",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "10 mioes mds",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "**nikyrie**, your life is maxed out",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E dboa",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "É 10% do meu lucro",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu acho",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "sei",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg withdraw 10m",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "**10,000,000** coins have been withdrawn",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "1 <:key10:603304907382063116> `dungeon key` successfully bought for 10,000,000 coins",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg buy dungeon key",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<:key10:603304907382063116> `Dungeon key` successfully bought for 10,000,000 coins",
        "data": "13:20 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ai meu pai",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q caro",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg deposit all",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "**228,139** coins have been deposited",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "**301,580** coins have been deposited",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg dungeon <@647798629641224192>",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "Entering the EPIC dungeon...",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mds",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Muita coisa",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@880817605772967946>, your EDGY sword is not fully charged yet",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Oque",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Slk roubado",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "1 vida",
        "data": "13:21 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa pedra",
        "data": "13:22 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Quem",
        "data": "13:22 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "0% de dano",
        "data": "13:22 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rlx",
        "data": "13:22 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Quer ficar na defesa?",
        "data": "13:22 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:22 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx",
        "data": "13:22 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu tanko",
        "data": "13:22 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@880817605772967946>, your EDGY sword is not fully charged yet",
        "data": "13:22 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx no imagina q eu morro mds",
        "data": "13:22 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "da dano ae",
        "data": "13:22 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "se que da k",
        "data": "13:22 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "N tem como",
        "data": "13:23 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tem q carregar a espada",
        "data": "13:23 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "attack",
        "data": "13:23 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:23 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "13:23 de 04/05/2024"
    },
    {
        "user": "Phasmochecker#3961",
        "mensagem": "",
        "data": "13:23 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:23 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "charge e attack",
        "data": "13:23 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "perfect",
        "data": "13:23 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "QUEM E LOSTI",
        "data": "13:23 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Oshi",
        "data": "13:23 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "13:23 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@880817605772967946>, your EDGY sword is not fully charged yet",
        "data": "13:23 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Aff",
        "data": "13:24 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:24 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "perai nois tem que ficar carregando até 100% e dai attack?",
        "data": "13:24 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "13:24 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sla",
        "data": "13:24 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Achei roubado",
        "data": "13:24 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@647798629641224192>, this spell is no longer available",
        "data": "13:24 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "serious",
        "data": "13:24 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:24 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora charge e charge",
        "data": "13:24 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:24 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:24 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "O healing",
        "data": "13:24 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "13:24 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "13:25 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Recupera 100 da sua vida",
        "data": "13:25 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "N usa agr",
        "data": "13:25 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "melhor quando nois estar quase off",
        "data": "13:25 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sim",
        "data": "13:25 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora pedrinha",
        "data": "13:25 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tirando a parte q eu ja usei-",
        "data": "13:25 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:25 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:25 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:25 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vish vou aguentar no",
        "data": "13:26 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "já sei",
        "data": "13:26 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "se attack eu defendo",
        "data": "13:26 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bl",
        "data": "13:26 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:26 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@880817605772967946>, your EDGY sword is not fully charged yet",
        "data": "13:26 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mano",
        "data": "13:26 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:26 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx até 100 que dá",
        "data": "13:26 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu vou dar charge na armadura",
        "data": "13:26 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "13:26 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tenho cura fi",
        "data": "13:26 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Se não for problema",
        "data": "13:26 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "a",
        "data": "13:27 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mas é so o teu",
        "data": "13:27 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "N o meu tbm",
        "data": "13:27 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:27 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:27 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "50%",
        "data": "13:27 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "13:27 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "caraca",
        "data": "13:27 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Nem percebi isso",
        "data": "13:27 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:27 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:27 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:27 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:28 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:28 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:28 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "muitos cálculos",
        "data": "13:28 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Real",
        "data": "13:28 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vou te proteger",
        "data": "13:28 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:28 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx",
        "data": "13:28 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bele",
        "data": "13:28 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "so charge",
        "data": "13:28 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:28 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:28 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "0",
        "data": "13:29 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tankei dms",
        "data": "13:29 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aham",
        "data": "13:29 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "13:29 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Nois tankou",
        "data": "13:29 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@880817605772967946>, this spell is no longer available",
        "data": "13:29 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:29 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:29 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:29 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:29 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:29 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "muitos cálculos",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Perdi vida",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg heal",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@880817605772967946>, you can't do this! end your previous command",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@647798629641224192>, this spell is no longer available",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Aff",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "oooooooh",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "EU VOU ATACAR",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu scho q da",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "se tem cura né?",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Do acho",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "So",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tenho não",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ja sei",
        "data": "13:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vc se cura",
        "data": "13:31 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "recharge a armadura",
        "data": "13:31 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E fica me protegendo",
        "data": "13:31 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "no tenho cura k",
        "data": "13:31 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@647798629641224192>, this spell is no longer available",
        "data": "13:31 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ferrou",
        "data": "13:31 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Invulnerabilidade",
        "data": "13:31 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Usa",
        "data": "13:31 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:31 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "oof",
        "data": "13:31 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ce foi de f",
        "data": "13:31 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@880817605772967946>, this spell is no longer available",
        "data": "13:31 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "agora lasco",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@880817605772967946>, your EDGY sword is not fully charged yet",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mds",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "f",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ja er-",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@880817605772967946>, this spell is no longer available",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "a",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "f",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "YO",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "boa",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Foi",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Hehe",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vai vai vai vai viav iaiaviv a",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@880817605772967946>, this spell is no longer available",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "65 + 20",
        "data": "13:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "oh no",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@880817605772967946>, your EDGY sword is not fully charged yet",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "se consegue",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Reza",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "TO VIVO",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "FALTA 20",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eh",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Fomos",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "f",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Conhecer Deus",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg rd",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ooooooooof",
        "data": "13:33 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg profile",
        "data": "13:34 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:34 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:34 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "poco",
        "data": "13:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Slk",
        "data": "13:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bixo destruiu nois",
        "data": "13:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg weekly",
        "data": "13:34 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "13:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg rd",
        "data": "13:34 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:34 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q area eu tô",
        "data": "13:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg tractor",
        "data": "13:34 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:35 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg profile <@647798629641224192>",
        "data": "13:35 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:35 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "to na 10",
        "data": "13:35 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "13:35 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ce tem mais nivel q eu-",
        "data": "13:35 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mas tem menos vids",
        "data": "13:35 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx que eu consigo 10M dnv",
        "data": "13:35 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Menos defesa",
        "data": "13:35 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E ataque",
        "data": "13:35 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "inclusive acho melhor criar outro canal em",
        "data": "13:35 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "13:35 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu vou olhar um server",
        "data": "13:36 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ali",
        "data": "13:36 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "To indo ali",
        "data": "13:36 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ok",
        "data": "13:36 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:36 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Voltei",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Aca vazio",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tava",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tendi",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg rd",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Lançou um treco novo",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Chamado card hand",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu ainda não entendi",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ainda",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "<@647798629641224192>, you don't have a quest anymore",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:37 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:38 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg daily",
        "data": "13:38 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:38 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:38 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg adventure",
        "data": "13:38 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg arena",
        "data": "13:38 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:38 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "**nikyrie**, your life is maxed out",
        "data": "13:38 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q demora",
        "data": "13:38 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:38 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "13:38 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tome",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx que eu sou pr",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pro*",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg duel <@647798629641224192>",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vem então",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pera",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg duel <@647798629641224192>",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds olha q matei",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Q",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que dá mais dano",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quase",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Por piuco",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pouco*",
        "data": "13:39 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:40 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg top coins",
        "data": "13:40 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:40 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg top level",
        "data": "13:40 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:40 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ladrão",
        "data": "13:40 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "k",
        "data": "13:40 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mano",
        "data": "13:40 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "se melhor q um eu melhor q outro",
        "data": "13:40 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hehe",
        "data": "13:40 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Como q o rpg bot é lvl 1",
        "data": "13:40 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "idk",
        "data": "13:40 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E ele tem 26 de xo",
        "data": "13:40 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Xp",
        "data": "13:40 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Rpg inventory",
        "data": "13:41 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:41 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "criar outro canal ae",
        "data": "13:41 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "per",
        "data": "13:41 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q demora",
        "data": "13:41 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ja vlt",
        "data": "13:42 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Foi mal",
        "data": "13:54 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tava fazendo meu ao mosso",
        "data": "13:54 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Eu ainda no k",
        "data": "13:55 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:55 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "13:56 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Balde falando q ia almoçar",
        "data": "14:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Daq a pouco eu vendo ele jogando um jogo singleplayer",
        "data": "14:21 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "14:21 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "a",
        "data": "15:05 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "balde",
        "data": "15:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "15:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "15:14 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Que esperto ele no?",
        "data": "15:25 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sera",
        "data": "15:27 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Obvius",
        "data": "15:27 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bem óbvio",
        "data": "15:28 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Óbviously",
        "data": "15:28 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "15:28 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@&1236361253832884324> o teu cargo",
        "data": "15:28 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nossa",
        "data": "15:28 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Botei de branco pq branco é paz",
        "data": "15:28 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "🏳️",
        "data": "15:28 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Serious?",
        "data": "15:28 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sim",
        "data": "15:28 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Coloca vermelho",
        "data": "15:28 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tirando a parte q eu não sabia q cor botar",
        "data": "15:28 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ok",
        "data": "15:28 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "15:29 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Perfect",
        "data": "15:29 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Já vlt",
        "data": "15:29 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "volta la",
        "data": "15:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "fiz pequenas coisas",
        "data": "15:38 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "15:38 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "de acordo com oque aconteceu com o server",
        "data": "15:38 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "os vestígios esquecido por algumas pessoas",
        "data": "15:38 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "15:38 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "bruna",
        "data": "15:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "bora botar todos os bots possíveis aqui no server?",
        "data": "15:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "descobri algo muito interessante",
        "data": "15:45 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "se nois chegar a mil membros",
        "data": "15:45 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "contando com bots",
        "data": "15:45 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "nos conseguimos criar uma comunidade",
        "data": "15:45 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "foda ne",
        "data": "15:45 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "(uma comunidade aberta,ou seja qualquer um pode entrar)",
        "data": "15:45 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "agora você me pergunta praq(provavelmente não perguntou),o praq é pra... nada",
        "data": "15:46 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "so pra termos uma conquista nesse servidor",
        "data": "15:46 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "mil membros é pouco tbm",
        "data": "15:46 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "demoraria provavelmente 1 mes pra nois botar mais de mil bots nesse server",
        "data": "15:47 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu acho",
        "data": "15:47 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ate agora nois temos 39",
        "data": "15:47 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "agora q parei prs pensar",
        "data": "15:50 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "nos teríamos todos os tipos de bot, entretenimiento,jogos, moderação, etc",
        "data": "15:50 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ainda mais q nos ja temos",
        "data": "15:50 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "/bakr",
        "data": "15:56 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "/bake",
        "data": "15:56 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "loucura",
        "data": "15:56 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "minha barra slash não funciona",
        "data": "15:56 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "oia só quem fala",
        "data": "18:35 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ter 1000 no server vai fazer nois os mais famosos",
        "data": "18:36 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "imagina a galera entrar e dar tudo errado, quis dizer certo",
        "data": "18:36 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "1000 bots é ez",
        "data": "18:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "só falta acha",
        "data": "18:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx que eu consiguo colocar tudo em um só dia",
        "data": "18:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "oh my god imagina 1000",
        "data": "18:38 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "imagina dar o everyone ;000000000000000",
        "data": "18:38 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa já to experando",
        "data": "18:38 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "perai que vou dar um cargo universal para cada",
        "data": "18:39 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "consiguo nop",
        "data": "18:40 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "então bora anti edu raivas",
        "data": "18:40 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "no tem nada falando de spamar 1000x bots no server para ficar mutado >)",
        "data": "18:41 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "raap",
        "data": "18:41 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa",
        "data": "18:41 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "to com sonhos na lua",
        "data": "18:42 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "my god meu desejo se realizaras por min mesmo >)",
        "data": "18:42 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:42 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quase que adiciono bot sem estar logado na conta",
        "data": "18:43 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "melhor",
        "data": "18:44 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vou meter foto para todo mundo",
        "data": "18:44 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "adivinha o primeiro",
        "data": "18:44 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "18:44 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hehehehe",
        "data": "18:44 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:45 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:45 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ou melhor ele",
        "data": "18:45 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ou ela",
        "data": "18:45 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "18:45 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah é privado",
        "data": "18:46 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "dane-se todos veram",
        "data": "18:46 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quase adicionei um adicionado k",
        "data": "18:47 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Slk",
        "data": "18:48 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm de musica pedra deves gostar",
        "data": "18:48 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "oh my god ele tá vivo",
        "data": "18:48 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bruna ta querendo isso",
        "data": "18:48 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vddddd",
        "data": "18:48 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Qual",
        "data": "18:48 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quase",
        "data": "18:48 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nad n",
        "data": "18:48 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "qual era o nome dela mesmo?",
        "data": "18:48 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Qual",
        "data": "18:48 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hehe",
        "data": "18:48 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Qiqi",
        "data": "18:48 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?",
        "data": "18:48 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ah não",
        "data": "18:49 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ela não",
        "data": "18:49 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "uma bem específica",
        "data": "18:49 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Nem lembro o nome",
        "data": "18:49 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mas ru sei quem é",
        "data": "18:49 de 04/05/2024"
    },
    {
        "user": "Nekotina#0608",
        "mensagem": "",
        "data": "18:49 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "perfect",
        "data": "18:49 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu sabia q era ela",
        "data": "18:49 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "obvius",
        "data": "18:49 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Agora eu quero ver",
        "data": "18:49 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quem não lembra da pedra falando bot hentai",
        "data": "18:49 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "k",
        "data": "18:49 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kk",
        "data": "18:49 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "+ship <@880817605772967946> <@429457053791158281>",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Aff",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quase",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mas tava em 0-",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu lembro",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "45%",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tava em 0",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "só a pedra kk",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ce gosta dela",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E ela gosta de yi",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Deve pegar um 98%",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "+ship <@647798629641224192> <@429457053791158281>",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Confia-",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho q no",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nikytina",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Perfect",
        "data": "18:50 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "+jooj <@880817605772967946>",
        "data": "18:51 de 04/05/2024"
    },
    {
        "user": "Loritta#0219",
        "mensagem": "<@880817605772967946>",
        "data": "18:51 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mudo muito k",
        "data": "18:51 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "A franjinha",
        "data": "18:51 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "18:51 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "+ojjo <@880817605772967946>",
        "data": "18:51 de 04/05/2024"
    },
    {
        "user": "Loritta#0219",
        "mensagem": "<@880817605772967946>",
        "data": "18:51 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "KAKAKKAKAKA",
        "data": "18:51 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "olha pra cara do gato",
        "data": "18:51 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sabe oque me lembrou..",
        "data": "18:51 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "um gato",
        "data": "18:52 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q gatona em",
        "data": "18:52 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "18:53 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "como q conta",
        "data": "18:53 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "+1",
        "data": "18:53 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "genius qi",
        "data": "18:53 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Hmmm",
        "data": "18:54 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pera",
        "data": "18:54 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "c! channel",
        "data": "18:54 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "",
        "data": "18:54 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "boa",
        "data": "18:54 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "essa foto",
        "data": "18:55 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Se bem q parece né",
        "data": "18:55 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "coloca tempos atrais da aleamanha",
        "data": "18:55 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "18:55 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "",
        "data": "18:55 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "18:55 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q gata",
        "data": "18:55 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Real",
        "data": "18:55 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ninguém entende como ta a mente do palhaço...",
        "data": "18:56 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "18:56 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q aquilo ali tras em",
        "data": "18:56 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "em",
        "data": "18:56 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "em",
        "data": "18:56 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "em",
        "data": "18:56 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "e",
        "data": "18:56 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "To vendo",
        "data": "18:56 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:56 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu ja mandei isso?",
        "data": "18:57 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "18:57 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nunca",
        "data": "18:57 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "18:57 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Uau",
        "data": "18:57 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bruna",
        "data": "18:57 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "perfect",
        "data": "18:57 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vc quer bota o cargo nos bot",
        "data": "18:57 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "how?",
        "data": "18:57 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E eu trago eles?",
        "data": "18:57 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ok",
        "data": "18:57 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "traga 9999999999999999999999999",
        "data": "18:57 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu consigo trazet facilmente",
        "data": "18:58 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "boa",
        "data": "18:58 de 04/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "",
        "data": "18:58 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Se prepara",
        "data": "18:58 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ok",
        "data": "18:58 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera q cargo eu adiciono",
        "data": "18:58 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "18:58 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Robo incrível",
        "data": "18:59 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@&1089939058555371651>",
        "data": "18:59 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ata",
        "data": "19:00 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "my god",
        "data": "19:00 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quanto bot",
        "data": "19:00 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quase adicionei cargo a alguém",
        "data": "19:00 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "PIZZA",
        "data": "19:01 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";00000000",
        "data": "19:01 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds onde se tá achando kkkkkkkkk",
        "data": "19:01 de 04/05/2024"
    },
    {
        "user": "SoundCloud#3508",
        "mensagem": "",
        "data": "19:01 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Quanto?",
        "data": "19:02 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "25",
        "data": "19:02 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "adiciona mais ae",
        "data": "19:02 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mds",
        "data": "19:02 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "KKKKKKKKKKKKKK",
        "data": "19:03 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds adicionou o balde",
        "data": "19:05 de 04/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "**You attack nothing. Good job Einstein!**",
        "data": "19:05 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "19:05 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Oh no",
        "data": "19:06 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "eu não sabia que era tão físico em",
        "data": "19:06 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tem uma quantidade limitada de bot",
        "data": "19:06 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": ":((((((",
        "data": "19:06 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "So pode 50",
        "data": "19:06 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "serious?",
        "data": "19:06 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Injusto-",
        "data": "19:06 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sim",
        "data": "19:06 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "19:06 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "19:06 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "uma hora edu acorda",
        "data": "19:06 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "19:06 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que eu hospedo meu bot perm dnv?",
        "data": "19:07 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera onde eu coloquei o código dele",
        "data": "19:07 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "genius",
        "data": "19:07 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Faz idso",
        "data": "19:07 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Meu bot ta abandonado",
        "data": "19:07 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Kk",
        "data": "19:07 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "perae que meu onedrive tá meio pesado para achar más eu acho",
        "data": "19:07 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "boa",
        "data": "19:07 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vou ligar ele",
        "data": "19:07 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "19:08 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "cada coisa que eu acho em",
        "data": "19:08 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "achei",
        "data": "19:08 de 04/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@647798629641224192> has reached level **1**. GG!",
        "data": "19:08 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "50kb",
        "data": "19:08 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa",
        "data": "19:08 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "19:08 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "19:08 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "19:08 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "19:08 de 04/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "Vote Booster: Vote now for a 10% boost. <https://arcane.bot/vote>",
        "data": "19:09 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "19:09 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q qualidade em",
        "data": "19:09 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa o código inteiro tem mais de 110kb",
        "data": "19:10 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kerabaites?",
        "data": "19:10 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "19:10 de 04/05/2024"
    },
    {
        "user": "PizzaTown#2272",
        "mensagem": "",
        "data": "19:11 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pizza",
        "data": "19:11 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "19:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Cara",
        "data": "19:16 de 04/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@880817605772967946> has reached level **1**. GG!",
        "data": "19:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "O comando q du te trolei",
        "data": "19:16 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds q susto",
        "data": "19:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu*",
        "data": "19:16 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "alias",
        "data": "19:16 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@880817605772967946>",
        "data": "19:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Foi um",
        "data": "19:16 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "como era o nome dos comandos lá que se pediu?",
        "data": "19:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1081004353877458944>",
        "data": "19:16 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "era tree alguma coisa",
        "data": "19:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pera não foi",
        "data": "19:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1081004353877458944>",
        "data": "19:17 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tbm n",
        "data": "19:17 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "boa",
        "data": "19:17 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "árvore de comandos",
        "data": "19:19 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "achei",
        "data": "19:19 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm deixa eu entende como funciona que jájá aprendo how",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1081004353877458944>",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "Apagando todas as mensagens de <@647798629641224192>",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Isso",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "NOP",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Era mentira",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ufa",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Não apagava",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds meu coração disparou",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1081004353877458944>",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "Apagando todas as mensagens de <@647798629641224192>",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1081004353877458944>",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "Apagando todas as mensagens de <@647798629641224192>",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "oia pedra",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@647798629641224192> has reached level **2**. GG!",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quase se me mata",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Kk",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "19:20 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Real",
        "data": "19:21 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Kicka ele",
        "data": "19:21 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "19:21 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vagabundo esse bot",
        "data": "19:21 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Slk",
        "data": "19:21 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q triste",
        "data": "19:21 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "deixa ae obvius que vou tar mais que o dobro dos leveis dos outros k",
        "data": "19:21 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Olha pro status do meu bot kk",
        "data": "19:21 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Jogando uma pedra no seu avô",
        "data": "19:22 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm?",
        "data": "19:22 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "19:22 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "qqqqqqqqqqqqqq",
        "data": "19:22 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Nem lembro de botar isdo",
        "data": "19:22 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Isso",
        "data": "19:22 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds k",
        "data": "19:22 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "O meu é diferente",
        "data": "19:22 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Jogando um tijolo na cabeça da sua família",
        "data": "19:22 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "19:22 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "slash commands mds",
        "data": "19:25 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "O meu não funciona",
        "data": "19:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Q triste prs mim",
        "data": "19:30 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "que pena",
        "data": "19:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Real",
        "data": "19:30 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aprendi o slash commands k",
        "data": "19:30 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm eu vou usar o negócio para testar se vai ou noi",
        "data": "19:33 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "!membros",
        "data": "19:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "!membro",
        "data": "19:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eh",
        "data": "19:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "!Membros",
        "data": "19:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "!MEMBROS",
        "data": "19:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "nao da",
        "data": "19:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "bot ruim",
        "data": "19:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "voce",
        "data": "19:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "nao",
        "data": "19:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ru",
        "data": "19:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "nos",
        "data": "19:34 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1081004353877458944> membros",
        "data": "19:35 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "19:35 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "Apagando todas as mensagens de <@647798629641224192>",
        "data": "19:35 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pera",
        "data": "19:35 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1081004353877458944> membros",
        "data": "19:35 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Funcionou",
        "data": "19:35 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Muito bem",
        "data": "19:36 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "19:36 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1081004353877458944> Membros",
        "data": "19:36 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "<@880817605772967946> Tem 62,Nesse servidor.",
        "data": "19:36 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "62",
        "data": "19:36 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu botei com M maiúsculo",
        "data": "19:36 de 04/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@880817605772967946> has reached level **2**. GG!",
        "data": "19:36 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Gênio",
        "data": "19:36 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "19:36 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aliás eu esqueci como conecta o bot",
        "data": "19:36 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tu usa qual?",
        "data": "19:36 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vou testar tudo até dar certo",
        "data": "19:36 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pra progamar o bot",
        "data": "19:36 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm acho q não é esse no",
        "data": "19:37 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ah",
        "data": "19:39 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?aleatorio",
        "data": "19:40 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "0",
        "data": "19:40 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mds",
        "data": "19:40 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Finalmente foi sem menção",
        "data": "19:40 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "19:40 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "OBRIGADO DEUS",
        "data": "19:40 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Literalmente pela primeira vez isso aconteceu",
        "data": "19:40 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Literalmente",
        "data": "19:40 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "boa",
        "data": "19:40 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "19:41 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Xo testar algo",
        "data": "19:41 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "? aleatorio",
        "data": "19:41 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?aleatorio",
        "data": "19:41 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "$random3",
        "data": "19:41 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Calma",
        "data": "19:41 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Erros técnicos",
        "data": "19:41 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "foi",
        "data": "19:42 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "eu acho",
        "data": "19:42 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "glória",
        "data": "19:42 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "/teste",
        "data": "19:42 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa q foi",
        "data": "19:42 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "teste",
        "data": "19:43 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "19:43 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "(eu não troquei o nome do comando)",
        "data": "19:43 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?aleatorio",
        "data": "19:43 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "Error at 2:16. Function `$enableDecimals` expects arguments!",
        "data": "19:43 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Acho q falta >1",
        "data": "19:43 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "boa",
        "data": "19:43 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?aleatorio 1+1",
        "data": "19:44 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "2",
        "data": "19:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Foi",
        "data": "19:44 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tenta agora 1-1",
        "data": "19:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?aleatorio 1-1",
        "data": "19:44 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "0",
        "data": "19:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Real",
        "data": "19:44 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tenta 1.0+1.0",
        "data": "19:44 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?aleatorio 1.0+1.0",
        "data": "19:45 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "2",
        "data": "19:45 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Real",
        "data": "19:45 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tenta 1+1-¹",
        "data": "19:45 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?aleatorio 909272927+28262872-2927287×29278÷2982",
        "data": "19:45 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "❌ Function `$calculate` at `3:20` returned an error: Math expression is invalid",
        "data": "19:45 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ata",
        "data": "19:45 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Acho q o × não existe",
        "data": "19:45 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Triste",
        "data": "19:45 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "19:45 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "/teste",
        "data": "19:46 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "funciona fi",
        "data": "19:46 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "19:46 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?c 80-80+70÷7",
        "data": "19:46 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "❌ Function `$calculate` at `3:20` returned an error: Math expression is invalid",
        "data": "19:46 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bugou",
        "data": "19:46 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Acho q n existe ÷",
        "data": "19:46 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "19:46 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Realmente",
        "data": "19:47 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E/",
        "data": "19:47 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "É /",
        "data": "19:47 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?c 80+80/90",
        "data": "19:47 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "80",
        "data": "19:47 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Real",
        "data": "19:47 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Multiplicação é*",
        "data": "19:47 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?c 70*70/70+70",
        "data": "19:48 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "140",
        "data": "19:48 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Real",
        "data": "19:48 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "qq é power",
        "data": "19:48 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "potência?",
        "data": "19:48 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ah",
        "data": "19:48 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "lembrei",
        "data": "19:48 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?c 80+80/80*80-80**80",
        "data": "19:48 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "-176684706477838460000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
        "data": "19:48 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Caralho",
        "data": "19:49 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Fiquei impressionado",
        "data": "19:49 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "A quantidade de zero <@647798629641224192>",
        "data": "19:49 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "19:49 de 04/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@647798629641224192> has reached level **3**. GG!",
        "data": "19:49 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "19:49 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?c 90-90",
        "data": "19:50 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pera",
        "data": "19:51 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Slk manjei no bot do nada",
        "data": "19:52 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?c 80-80",
        "data": "19:52 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "O resultado da sua pergunta é: 0!",
        "data": "19:52 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Agora sim",
        "data": "19:52 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu botei perguntas",
        "data": "19:52 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu vou fazer em embed",
        "data": "19:52 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu acho",
        "data": "19:52 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Nah",
        "data": "19:52 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "19:52 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vou botar metion",
        "data": "19:52 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "19:53 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ja vlt",
        "data": "19:53 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Volta",
        "data": "20:00 de 04/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@880817605772967946> has reached level **3**. GG!",
        "data": "20:00 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Cala boca",
        "data": "20:00 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?deletar 1",
        "data": "20:00 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Errei",
        "data": "20:01 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 1",
        "data": "20:01 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "Error at 4:51. Expected `]` at the end of `$argsCheck`.",
        "data": "20:01 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ah",
        "data": "20:01 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Valeu",
        "data": "20:01 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sempre esqueço isso slk",
        "data": "20:02 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir",
        "data": "20:02 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 2",
        "data": "20:02 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Oi",
        "data": "20:02 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Funcionando",
        "data": "20:02 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Oia*",
        "data": "20:02 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "20:02 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Slk",
        "data": "20:02 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "20:03 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 1",
        "data": "20:04 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "errei?",
        "data": "20:04 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 1",
        "data": "20:04 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Acho q acabou o tempo",
        "data": "20:04 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "foi nal",
        "data": "20:08 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 1",
        "data": "20:08 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "Error at 4:12. Function `$mentioned` expects arguments!",
        "data": "20:08 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "argumentos",
        "data": "20:08 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "quem precisa de argumentos",
        "data": "20:10 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "? excluir 1",
        "data": "20:10 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "20:10 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 1",
        "data": "20:10 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 2",
        "data": "20:10 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu acho",
        "data": "20:10 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "20:10 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "so acho",
        "data": "20:10 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "q fiz merda",
        "data": "20:11 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 1",
        "data": "20:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "fiz",
        "data": "20:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "uma cagadola",
        "data": "20:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sinistra",
        "data": "20:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?membros",
        "data": "20:12 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "<@880817605772967946> Existem,62,de membros nesse servidor!",
        "data": "20:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "oshi",
        "data": "20:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "fumou",
        "data": "20:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ja volto",
        "data": "20:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "q nem a bruna",
        "data": "20:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "voltei",
        "data": "20:17 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "20:17 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "qnd eu disse isso",
        "data": "20:17 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "fumei",
        "data": "20:17 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "20:17 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir",
        "data": "20:17 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "❌-Falha ao usar esse comando,veja se você digitou certo esse comando. Caso não conheça os comandos digite ?ajuda para ver a lista de comandos.",
        "data": "20:17 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "esse bot ta chapado",
        "data": "20:18 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 3",
        "data": "20:18 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ta não",
        "data": "20:18 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?apagar 2",
        "data": "20:25 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 3",
        "data": "20:25 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "<@880817605772967946> [✔️-As mensagens foram apagadas com sucesso!]",
        "data": "20:25 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Acho q o máximo q da pra apagar é 3",
        "data": "20:26 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 2",
        "data": "20:26 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "<@880817605772967946> [✔️-As mensagens foram apagadas com sucesso!]",
        "data": "20:26 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Uai",
        "data": "20:26 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ata",
        "data": "20:26 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 2",
        "data": "20:27 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "<@880817605772967946> [✔️-As mensagens foram apagadas com sucesso!]",
        "data": "20:27 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "esse bot e chapado",
        "data": "20:27 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 1",
        "data": "20:27 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "<@880817605772967946> [✔️-As mensagens foram apagadas com sucesso!]",
        "data": "20:27 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "qq rlr apagou",
        "data": "20:27 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 4",
        "data": "20:27 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "<@880817605772967946> [✔️-As mensagens foram apagadas com sucesso!]",
        "data": "20:27 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ele ta chapado",
        "data": "20:28 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 6",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "<@880817605772967946> [✔️-As mensagens foram apagadas com sucesso!]",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ue",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ta nao6",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mano",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm?",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Olha isso",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 2",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "<@880817605772967946> [✔️-As mensagens foram apagadas com sucesso!]",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ele apagou o nada",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "O NADA",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q lgl né <@1054087411359039598>",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "real",
        "data": "20:30 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "? excluir 2",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "fala um comando pra eu adicionar",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds idro chegou 0.0000000000001 segundo depois de eu mandar a msg",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Real",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "sla",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "adiciona idro",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "**You didn't tag anyone! Do you want me to kill you?**",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "explica",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa idro",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "**<@1054087411359039598> and <@880817605772967946> engage in a heated game of intergalactic chess, with the loser being vaporized into atoms.**",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "A primeira coisa q ele faz",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "obvius",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Entendi tudo",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Pxi",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Oxi",
        "data": "20:31 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds xadrez intergalactico",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Eu ia da /kill no burn mas decidi a pedra",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "oia",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "safado",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ainda bem q sei xadrez",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "genius",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "aliás...",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ainda bem que não sei xadrez",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nem pensees",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bora um fight bruna",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "to que nem o idro",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Hehe.",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "**<@1054087411359039598>, don't kill. Killing is bad.**",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Só um",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que eu venço?",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": ":((((((",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sei não",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Tô nem aí",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "como era o site?",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Só mata logo",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Não to jogando recentemente",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "chess vdd",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Chess.com",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "imagina eu",
        "data": "20:32 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Kk",
        "data": "20:33 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Minhas últimas partidas eu perdi",
        "data": "20:33 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Mas teve uma partida..m",
        "data": "20:33 de 04/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@880817605772967946> has reached level **4**. GG!",
        "data": "20:33 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "entrei",
        "data": "20:33 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Que eu ganhei com 8 movimentos",
        "data": "20:33 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "boa",
        "data": "20:33 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Q rápido",
        "data": "20:33 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Perai",
        "data": "20:33 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "obvius",
        "data": "20:33 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "im the best",
        "data": "20:33 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@1054087411359039598>",
        "data": "20:33 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "sabia que eu me superestimo? até d++++++++++++++",
        "data": "20:34 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa",
        "data": "20:34 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quando será que ele entra",
        "data": "20:35 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "oh my god streamer de xadrez",
        "data": "20:36 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Manda pro pai",
        "data": "20:36 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Aliás bruna",
        "data": "20:36 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nem eu sei k",
        "data": "20:36 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm?",
        "data": "20:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "achei",
        "data": "20:37 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu treinei várias aberturar",
        "data": "20:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "20:37 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E armadilhas",
        "data": "20:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "20:37 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Aberturas*",
        "data": "20:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "20:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "20:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vou aprendendo no caminho",
        "data": "20:37 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bota",
        "data": "20:37 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bora",
        "data": "20:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "memória 999x",
        "data": "20:37 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ce nao viu nada",
        "data": "20:37 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "20:38 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q q era?",
        "data": "20:38 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "se falou alguma coisa?",
        "data": "20:38 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "entra lá",
        "data": "20:38 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "justo k",
        "data": "20:39 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "abertura reta, gambito reto aceitado q nome em",
        "data": "20:41 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "estourei uma espinha",
        "data": "20:47 de 04/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@647798629641224192> has reached level **4**. GG!",
        "data": "20:47 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "gente eu só to jogando com a memória passada k",
        "data": "20:52 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "abertura do rei peão: variante cavaleira do rei",
        "data": "20:55 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "21:12 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "So não perco de 4 pq é melhor de 3-",
        "data": "21:13 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Não sei pq sou prata",
        "data": "21:13 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Talvez pq eu fui pra um torneio",
        "data": "21:13 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "21:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "@everyone",
        "data": "21:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Oshi",
        "data": "21:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Funou",
        "data": "21:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Funou?",
        "data": "21:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Fumou",
        "data": "21:14 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@647798629641224192>",
        "data": "21:16 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "21:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@647798629641224192>",
        "data": "21:16 de 04/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "21:16 de 04/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "21:17 de 04/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Opa",
        "data": "10:54 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "10:54 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Olha só",
        "data": "10:54 de 05/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "you are currently accessing the proprietary api of assist: chat with ai (https://apps.apple.com/ua/app/assist-chat-with-ai/id6448989090). any access and/or usage outside of the assist app is unauthorized and prohibited",
        "data": "10:54 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será",
        "data": "10:54 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "10:54 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:10 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:10 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:10 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Álcool",
        "data": "11:10 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:10 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "11:10 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 10 segundos",
        "data": "11:10 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Óleo",
        "data": "11:10 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:10 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:10 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Serious",
        "data": "11:10 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:10 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "O feiticeiro",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vulcão",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Silvio Santos",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hm",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Faustão",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:11 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Não sabia",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Bts",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quase esqueci",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Free fire",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:12 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quase",
        "data": "11:13 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pensei que não ia k",
        "data": "11:13 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:13 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:13 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Paladar",
        "data": "11:13 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:13 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:13 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:13 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "11:13 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:13 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Protetor solar",
        "data": "11:13 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:13 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:13 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Proteje muito em",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "360",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "365",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hm",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Não sabia k",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "12",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:14 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ninhos",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Obvius",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Até o idro erraria",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "4",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Andar",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Andares",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hastes",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pilares",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pilar",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 10 segundos",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hasts",
        "data": "11:15 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Escada",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Sbt",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Que chute",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Coração",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tá no nome",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Por incrível que pareça o meu bate a 80 por segundo",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:16 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Relógio",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tem 1 no relógio e não tem o 0 q lógica em",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Dinheiro",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Im ricasso",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Iraque",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "França",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Alemanha",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "EUa",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "EUA",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 10 segundos",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Estados Unidos",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quase",
        "data": "11:17 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "18 já",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hehe",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Suco",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Coxinha",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Azeitona",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Abacate",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 10 segundos",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Churros",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pipoca",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⚠️ Tempo restante: 5 segundos",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Q q era",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nime",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nike",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:18 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Não sei porque mas o feminino da mais conforto k",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Medusa",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Cabelo em",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Brasil",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hehe",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Desodorante",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:19 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vedosorante é onde se diz aonde estou",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Cristal",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ala o Edu",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkkkk",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Cama",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Iceberg",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:20 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q peninha",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Saída",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Seria?",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "31",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "32",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "30",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "29",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:21 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Flauta",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Piano",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nossa",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Coca cola",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Bando de cachaceiro",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "7",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Lógica",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:22 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Noé",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quem falar Moisés é da antiga em",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Maio",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Que hard",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Xuxa",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@647798629641224192> has reached level **5**. GG!",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hehe",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Obvius",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:23 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vermelho",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Por incrível que pareça minha cor favorita é vermelho o",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "32",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "26",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Só",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Conta os assentos tbm e o cedilha",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Noite",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Que paz",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:24 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "China",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Lá que aconteceu mesmo k",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Sacados",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Safados*",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ta maluco fi,me acordano?",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Sogra",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkk",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Prima",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tá quae",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Cachorro",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "to lagando",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Boa",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "socorto",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Se vira",
        "data": "11:25 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Cala boca",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Queijo",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkkkkkk",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nossa pedra",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Rato",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Duvido vc passar meu recorde sozinho",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quase dz",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ez",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ok",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quanto é?",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Cadela",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quase cachorra",
        "data": "11:26 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Meu recorde é 63",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Laguei",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ok",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Norte",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Rlx que eu te chamo o quando acabar",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "S",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ana",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Flórida",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ana?",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Dim",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sim",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Sla",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "A Mãe de ana",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Banana",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tem 3 filhas",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Muita banana",
        "data": "11:27 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Fernanda,a ota sla,ana",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Batata",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Nossa",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Q pergunta",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q lógica",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "KKKKKK",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vou ga",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Participar*",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "4",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "3",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quase",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "oque",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Verde",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vermelho",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pq",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Eu cito a maior",
        "data": "11:28 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bora chegar nos 100",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Dengye",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Dengue",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pera é",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 10 segundos",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Cardiologia",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Paternidade",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Gravidez",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⚠️ Tempo restante: 5 segundos",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Não consigo pular aliás",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Preto",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Q",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Se vira",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Cala boca",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hehe",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Zeus",
        "data": "11:29 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q Zeus",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu ia falar astec-",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Boa",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vai",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Cinderela",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quem não sabe em",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu sei",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Boa",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "o idro",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Opa edu",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Touro",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Nem demorou pra voltar",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Obcius",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pelo menos o server reviveu -",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Y",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "X",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Yo",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Um em dois",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q sorte",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "um dos dois",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "aquele la",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "q carrega coisa",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Cavalo",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E pow",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Camelo",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sabe",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "noite",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Manhã",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nunca ouvi falar k",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "11:31 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "euro",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Cruzeiro",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Real",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Cruzeiro foi em 80",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ou 70",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Cruzeiro Real uai",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "1",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "6",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "6",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@647798629641224192> acertou!",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vdd",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quase 4",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "2",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "mais de 1",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@674267691627839510> has reached level **1**. GG!",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "12",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "nossa",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "q pro",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "6",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 10 segundos",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "0",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "24",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vai q da",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ata",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nds",
        "data": "11:32 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Confundi",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Uma dúzia é 12",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Meia dúzia é 6",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Churrasco",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "aquele la",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Drogaria",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 10 segundos",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Responde pow",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Farmácia",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Quero eu não",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⚠️ Tempo restante: 5 segundos",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Sei no",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bar",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Responde pow",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mdntira",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bora chegar nos 100",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "21",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "23",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "achei q era idroranga",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tão novo assim",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ne não edu",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Era a espaçonave do idro",
        "data": "11:33 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Q",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Prova",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Alcolidcod anônimos",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 10 segundos",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Idk",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Algo assim",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "aquele la",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pula",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⚠️ Tempo restante: 5 segundos",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Alcoólicos anônimos",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pulou",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nop?",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "5%",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Im pro",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Se 5% foi 23 minutos",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Imagina 50%",
        "data": "11:34 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "230 uai",
        "data": "11:35 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "11:35 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Horas",
        "data": "11:35 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Im genius",
        "data": "11:35 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "24?",
        "data": "11:35 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pera",
        "data": "11:35 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "mano",
        "data": "11:35 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu vou te dar um web chute",
        "data": "11:35 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "4?",
        "data": "11:35 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "q mizera",
        "data": "11:35 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Acho q 4",
        "data": "11:35 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "11:35 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ce vai de 4",
        "data": "11:35 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quatro oq mde",
        "data": "11:35 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "F edu",
        "data": "11:36 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Já vlt",
        "data": "11:36 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Voltou",
        "data": "11:37 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu também ja volto",
        "data": "11:37 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "voltei",
        "data": "12:05 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "12:15 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ata",
        "data": "12:17 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?numero",
        "data": "12:18 de 05/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "❌ Function `$random` at `2:39` returned an error: expected at least 2 arguments, got 1",
        "data": "12:18 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "q",
        "data": "12:18 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ata",
        "data": "12:18 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?numero",
        "data": "12:18 de 05/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "❌ Function `$random` at `2:41` returned an error: expected at least 2 arguments, got 1",
        "data": "12:18 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?numero",
        "data": "12:19 de 05/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "❌ Function `$random` at `2:41` returned an error: expected at least 2 arguments, got 1",
        "data": "12:19 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "tô entendendo nada",
        "data": "12:20 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Slk",
        "data": "12:20 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?numero",
        "data": "12:20 de 05/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "❌ Function `$random` at `2:40` returned an error: expected at least 2 arguments, got 1",
        "data": "12:20 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?numero",
        "data": "12:21 de 05/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "O seu número aleatório é **7**",
        "data": "12:21 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "loucura",
        "data": "12:21 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "12:24 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?numero",
        "data": "12:25 de 05/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "O seu número aleatório é **36**",
        "data": "12:25 de 05/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@880817605772967946> has reached level **5**. GG!",
        "data": "12:25 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Agr sim",
        "data": "12:25 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Afk",
        "data": "12:26 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Voltei",
        "data": "12:40 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Voltei²",
        "data": "12:51 de 05/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Sim pedra a gente entendeu",
        "data": "12:56 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "13:00 de 05/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Opa edu eae",
        "data": "13:06 de 05/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@1054087411359039598> has reached level **1**. GG!",
        "data": "13:06 de 05/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Volto da ressaca?",
        "data": "13:06 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "oque",
        "data": "13:10 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Fumou",
        "data": "13:10 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@1054087411359039598>",
        "data": "13:11 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tu que és gênio",
        "data": "13:11 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Diga um comando pra eu criar",
        "data": "13:11 de 05/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Na onde",
        "data": "13:16 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "13:17 de 05/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Shrek?",
        "data": "13:17 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E esse comando vai fazer oq",
        "data": "13:17 de 05/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Uma imagem do shrek",
        "data": "13:17 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Que comando útil",
        "data": "13:17 de 05/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Brigado",
        "data": "13:18 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sei",
        "data": "13:18 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Dps",
        "data": "13:27 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?excluir 15",
        "data": "14:08 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "14:08 de 05/05/2024"
    },
    {
        "user": "AliveBot#5722",
        "mensagem": "<@880817605772967946> ✔️-As mensagens foram apagadas com sucesso!",
        "data": "14:08 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "14:08 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds dei um espirro tão forte que quase mijei na calça",
        "data": "15:42 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quem nunca foi no banheiro no meio de uma ligação",
        "data": "15:48 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Oshi",
        "data": "17:53 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Agora q percebi q confundi espirro com espírito",
        "data": "18:23 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds",
        "data": "20:04 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Até pedra tá contaminada do “🇧🇷pão bão”",
        "data": "20:05 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510> Bem contaminante em",
        "data": "20:06 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "onde isdo",
        "data": "20:20 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Fofocas kkk",
        "data": "20:20 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sei",
        "data": "20:21 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkkkkkkkkk",
        "data": "20:21 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Agora q percebi q no edu tem a bandeira do brasil",
        "data": "20:21 de 05/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu pensei q era só pão bao",
        "data": "20:21 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Boa",
        "data": "20:22 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Vdd",
        "data": "21:46 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Bem contaminante ne",
        "data": "21:47 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Bem bem",
        "data": "21:47 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Muito pão bão né Edu",
        "data": "21:52 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "bastante pão bão",
        "data": "21:54 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "22:24 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Me lembra algo",
        "data": "22:25 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será que o Edu já se achou uma vez na vida?",
        "data": "22:26 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510> Será que já?",
        "data": "22:26 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Eu devia tar conversando com o dono para saber né",
        "data": "22:27 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera q ele ja",
        "data": "22:28 de 05/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@674267691627839510> has reached level **2**. GG!",
        "data": "22:28 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "22:28 de 05/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@647798629641224192> has reached level **6**. GG!",
        "data": "22:28 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "22:28 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "22:28 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds",
        "data": "22:28 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "3x seguidas",
        "data": "22:28 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510> New Record",
        "data": "22:29 de 05/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "22:29 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Caraca eu achei a única vez que o Edu se achou k",
        "data": "22:29 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "foi a vez q aquel foi isso assim dele",
        "data": "22:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdddddd",
        "data": "22:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q?",
        "data": "22:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Caraca eu realmente achei a única do mundo",
        "data": "22:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "22:30 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quer ver?",
        "data": "22:31 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "a unica",
        "data": "22:31 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Yes",
        "data": "22:31 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Burn é tão rápido que busca entre ≈80k de mensagem, processa e acha a certa e tira a foto e fala com o Edu no outro canal",
        "data": "22:31 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será que consigo fazer mais de 2 coisas ao mesmo tempo?",
        "data": "22:32 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será?",
        "data": "22:32 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quer ver mesmo?",
        "data": "22:33 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "mande",
        "data": "22:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Okay",
        "data": "22:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "22:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "22:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pera eu tirei uma parte da debaixo tbm",
        "data": "22:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nem eu lembro que eu tava falando k",
        "data": "22:33 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Lindeza kk",
        "data": "22:34 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "22:34 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Um curioso respondeu um curioso que outro curioso viu a resposta do curioso respondida pelo curioso",
        "data": "22:34 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q lógica",
        "data": "22:35 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "muita curiosidade",
        "data": "22:36 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Por falar nisso eu quase mandei a foto de um ;0",
        "data": "22:36 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "22:36 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será que deixei ainda mais curiosidade?",
        "data": "22:36 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será?",
        "data": "22:36 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "muita sereaciedadimente",
        "data": "22:37 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "22:37 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Meu corretor tá corrigindo kkkkk para kkkkkkk",
        "data": "22:37 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Imperdoável né",
        "data": "22:37 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "22:38 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Por falar nisso Edu",
        "data": "22:38 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Como você se atolou aqui?",
        "data": "22:39 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "acabou q aconteceu um bagui meio coisa do treco de negociar o negocio negossaçxado",
        "data": "22:39 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tendeu",
        "data": "22:39 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Obvius",
        "data": "22:40 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Na sexta marcha ainda",
        "data": "22:42 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510> Se que entende de carro ele vai até qual?",
        "data": "22:42 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "5?",
        "data": "22:42 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hm",
        "data": "22:42 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Im rapidassi",
        "data": "22:43 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Super",
        "data": "22:43 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Se carro tem marcha de 1 a 9 então a marcha ré vai de -1 a - 9?",
        "data": "22:43 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Im genius",
        "data": "22:44 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510> Isso dá?",
        "data": "22:44 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "da",
        "data": "22:44 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "22:44 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Já tento?",
        "data": "22:44 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Rlx que não é multado",
        "data": "22:44 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "e o P é de passar todo mundo ne",
        "data": "22:44 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ah",
        "data": "22:44 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Deve ser né",
        "data": "22:44 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "o C é de câmbio?",
        "data": "22:45 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ah entendi então o T é de transmissão",
        "data": "22:45 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "V de volante automático?",
        "data": "22:45 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510> Ta certo?",
        "data": "22:45 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "deve tar",
        "data": "22:45 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "pergunta pro pedra",
        "data": "22:45 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ">)",
        "data": "22:45 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Qui pedra oq",
        "data": "22:46 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ele deve entender de vento k",
        "data": "22:46 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "e se o R for de Rapidãozãoçãod+",
        "data": "22:46 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pode ser tbm né",
        "data": "22:46 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "O do avião é de V de Voar?",
        "data": "22:46 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "o do submarino é M de Mergulhar?",
        "data": "22:47 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "22:47 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Então é fácil?",
        "data": "22:47 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "pq ele é diferenciado",
        "data": "22:47 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ele é roxo de roxo",
        "data": "22:48 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "bem roxo",
        "data": "22:48 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "22:48 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "o bot de roxo",
        "data": "22:48 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "22:48 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Onde se tá vendo ele",
        "data": "22:48 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ali",
        "data": "22:49 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "nos bot",
        "data": "22:49 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hm",
        "data": "22:49 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hmmmmm",
        "data": "22:49 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Roxo é bem misterioso né",
        "data": "22:49 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "deve ser",
        "data": "22:49 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ata",
        "data": "22:50 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "o botão é de transmitindo",
        "data": "22:50 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "trans mentindo",
        "data": "22:50 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q botão?",
        "data": "22:50 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ata",
        "data": "22:50 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "o roxo",
        "data": "22:50 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tendi",
        "data": "22:50 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Burn atolando três vezes seguidas um carro é só no teste drive né",
        "data": "22:52 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "um mestre da volancia",
        "data": "22:52 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd porque não testamos isso no teste drive?",
        "data": "22:52 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Se ele atola é ruim se não é top >)",
        "data": "22:53 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "testa la",
        "data": "22:53 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tá bem noite sabe",
        "data": "22:53 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ta quase dia",
        "data": "22:53 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quase",
        "data": "22:53 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "cedo",
        "data": "22:53 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pera a noite é até 24?",
        "data": "22:53 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ma dai já é dia?",
        "data": "22:54 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds vai acaba o dia",
        "data": "22:54 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vddd",
        "data": "22:55 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Até hoje ele está lá",
        "data": "22:56 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Que final triste né Edu",
        "data": "22:56 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "22:56 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkkkkkk",
        "data": "22:56 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "acho q ele n loga desde esse dia ai",
        "data": "22:56 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Oh my god",
        "data": "22:57 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Se ;000000",
        "data": "22:57 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ixi ele volto",
        "data": "22:57 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Oh my god",
        "data": "22:57 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ele virou?",
        "data": "22:57 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "q pro",
        "data": "22:58 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "22:58 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Dois dias",
        "data": "22:58 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tá vivasso ainda",
        "data": "22:58 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Cachorro tá encarando em",
        "data": "22:59 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "encarando oce em",
        "data": "22:59 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "eu n",
        "data": "22:59 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Misericórdia",
        "data": "22:59 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Parece o Edu antigamente",
        "data": "22:59 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "É mesmo",
        "data": "22:59 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Se lembra?",
        "data": "22:59 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será que tenho uma foto mais clara que o print?",
        "data": "22:59 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sla",
        "data": "23:00 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds eu tenho",
        "data": "23:00 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "My god",
        "data": "23:00 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Edu tá mais que mais mds",
        "data": "23:01 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "23:01 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Oia só",
        "data": "23:01 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quase mandei a foto Edu uwu 2D png",
        "data": "23:01 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "brilhava em",
        "data": "23:01 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "23:01 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "é oq",
        "data": "23:01 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nada n",
        "data": "23:01 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vddd",
        "data": "23:02 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Xiiii nada n",
        "data": "23:02 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Um dia eu aprendo a falar baixo",
        "data": "23:02 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "pq em",
        "data": "23:02 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pera mas tô falando alto",
        "data": "23:02 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nem eu sei",
        "data": "23:02 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Im im",
        "data": "23:02 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkkkkkkk nossa mas se não fosse pelo deslize quase em",
        "data": "23:03 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Bem eu vou ir",
        "data": "23:04 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tá quase dia já",
        "data": "23:04 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Magina eu ter menos de 30 minutos de sono",
        "data": "23:04 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Né Edu",
        "data": "23:04 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "alta velocidade",
        "data": "23:05 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "23:05 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q rápido",
        "data": "23:12 de 05/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@647798629641224192> has reached level **7**. GG!",
        "data": "23:12 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "23:12 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quanto mais mais?",
        "data": "23:12 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Percebi que tô com insônia",
        "data": "23:12 de 05/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Dane-se dormirei mesmo assim",
        "data": "23:13 de 05/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Como se livrar da insônia: dormir",
        "data": "03:04 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Genius",
        "data": "03:05 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hehe",
        "data": "06:18 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "hoje",
        "data": "11:00 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "é",
        "data": "11:00 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "dia",
        "data": "11:00 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "que meu fone não chega",
        "data": "11:01 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "e tambem e um dia",
        "data": "11:01 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "novo",
        "data": "11:01 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vivo",
        "data": "11:01 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu",
        "data": "11:01 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "e quade todos",
        "data": "11:01 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "quase*",
        "data": "11:01 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Boa",
        "data": "12:54 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ctz que compro da shopee",
        "data": "12:54 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pera eu recebi notificação de min mesmo",
        "data": "16:54 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "gênio ainda abre e responde ele mesmo mds",
        "data": "16:55 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkkkkkkk",
        "data": "16:55 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm para que serve esses bots?",
        "data": "16:56 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aham",
        "data": "16:56 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah",
        "data": "16:56 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera",
        "data": "16:56 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ah",
        "data": "16:56 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "agora entendi",
        "data": "16:56 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds eu pensei que era 8 e ele responde que provavelmente dai ele aham e ele sim",
        "data": "16:56 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "16:56 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "e esse?",
        "data": "16:57 de 06/05/2024"
    },
    {
        "user": "Truth or Dare#8712",
        "mensagem": "",
        "data": "16:57 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Im not gay",
        "data": "16:57 de 06/05/2024"
    },
    {
        "user": "Truth or Dare#8712",
        "mensagem": "<a:animated_sparkles:1204952794772279336> **TIP:** Upgrade to premium to prevent repeated questions! Tap \"Upgrade\" on my profile.",
        "data": "16:57 de 06/05/2024"
    },
    {
        "user": "Truth or Dare#8712",
        "mensagem": "",
        "data": "16:57 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ata",
        "data": "16:58 de 06/05/2024"
    },
    {
        "user": "Truth or Dare#8712",
        "mensagem": "",
        "data": "16:58 de 06/05/2024"
    },
    {
        "user": "Truth or Dare#8712",
        "mensagem": "",
        "data": "16:58 de 06/05/2024"
    },
    {
        "user": "Truth or Dare#8712",
        "mensagem": "",
        "data": "16:58 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "16:58 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "16:59 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hi may god fui convidado por uma garota bot png 2D",
        "data": "17:00 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "próximo",
        "data": "17:00 de 06/05/2024"
    },
    {
        "user": "PizzaTown#2272",
        "mensagem": "",
        "data": "17:01 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "AAAAAAAAAAAA",
        "data": "17:01 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "próximo",
        "data": "17:01 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:01 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "17:01 de 06/05/2024"
    },
    {
        "user": "Picsart#0400",
        "mensagem": "",
        "data": "17:01 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "17:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Bem tomboy em",
        "data": "17:02 de 06/05/2024"
    },
    {
        "user": "Picsart#0400",
        "mensagem": "",
        "data": "17:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "h",
        "data": "17:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "m",
        "data": "17:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bor",
        "data": "17:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora*",
        "data": "17:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "17:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tem como reviver o edu como PNG 2D ;0",
        "data": "17:03 de 06/05/2024"
    },
    {
        "user": "Picsart#0400",
        "mensagem": "",
        "data": "17:03 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Top temas",
        "data": "17:03 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "17:03 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Que transição mais linda",
        "data": "17:04 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "me lembra a batata se descacando se autoralando na raladeira caindo na frigideira se cozinhando",
        "data": "17:04 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pera",
        "data": "17:04 de 06/05/2024"
    },
    {
        "user": "Picsart#0400",
        "mensagem": "",
        "data": "17:05 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "perfect tema",
        "data": "17:05 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aff",
        "data": "17:05 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "17:05 de 06/05/2024"
    },
    {
        "user": "Picsart#0400",
        "mensagem": "",
        "data": "17:06 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será que ele entende?",
        "data": "17:06 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa mudo muit",
        "data": "17:06 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera",
        "data": "17:06 de 06/05/2024"
    },
    {
        "user": "Picsart#0400",
        "mensagem": "",
        "data": "17:07 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será?",
        "data": "17:07 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "17:07 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa mudo muit-",
        "data": "17:07 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds coloco um chapéu na minha caebçota",
        "data": "17:07 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "cabeçota*",
        "data": "17:08 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "17:08 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "App de date online via server público no discord",
        "data": "17:08 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "17:09 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "MÁI GOD DATE ONLINE",
        "data": "17:11 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "5 mensagem por minuto",
        "data": "17:12 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds to no ceu",
        "data": "17:12 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hm bem compleçsow",
        "data": "17:13 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds vou me deitar online",
        "data": "17:15 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Um nome..",
        "data": "17:16 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Perfect",
        "data": "17:16 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Idade",
        "data": "17:17 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Perfect+++++++++++++++++++++++++",
        "data": "17:17 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ainda bem que incesto no brasil não é ilegal k",
        "data": "17:17 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "cansei",
        "data": "17:23 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "próximo",
        "data": "17:24 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "elá mesmo",
        "data": "17:24 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "“Nekotina”",
        "data": "17:24 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nossa",
        "data": "17:25 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pizza com pizza é quase casal perfeito",
        "data": "17:25 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quase",
        "data": "17:25 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "13%",
        "data": "17:25 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Rapa tem uma elevação em",
        "data": "17:26 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será?",
        "data": "17:26 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "17:26 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Duas garotas ;0000",
        "data": "17:26 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Rapa hoje em dai tá em febre em",
        "data": "17:26 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Aff",
        "data": "17:27 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Caraca 7%%%%%%%%%%%%%%%%",
        "data": "17:27 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "17:27 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quem não gosta de pizza né",
        "data": "17:28 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Rapa eu acho que me interesso mais pelo 3D em vez do 2D em",
        "data": "17:28 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Porque será",
        "data": "17:28 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será?",
        "data": "17:28 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho q s",
        "data": "17:29 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "17:29 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "próximo",
        "data": "17:30 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "serious",
        "data": "17:30 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q caro é tudo em dolar",
        "data": "17:30 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "17:31 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:31 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "17:31 de 06/05/2024"
    },
    {
        "user": "Make it a Quote#6660",
        "mensagem": "",
        "data": "17:31 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds nunca fui tanto em um site",
        "data": "17:33 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "17:33 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "próximo",
        "data": "17:34 de 06/05/2024"
    },
    {
        "user": "Karuta#1280",
        "mensagem": "<@647798629641224192>, you must verify your account to use that command. Please use the `k!verify` command, then follow the instructions.",
        "data": "17:34 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "k!verify",
        "data": "17:34 de 06/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@647798629641224192> has reached level **8**. GG!",
        "data": "17:34 de 06/05/2024"
    },
    {
        "user": "Karuta#1280",
        "mensagem": "<@647798629641224192>, check your DM to proceed with verification.",
        "data": "17:34 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "he",
        "data": "17:35 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "glória",
        "data": "17:36 de 06/05/2024"
    },
    {
        "user": "Karuta#1280",
        "mensagem": "<@647798629641224192>, the `drop` command is restricted in this channel.",
        "data": "17:36 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "AAAAAAAA",
        "data": "17:36 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "próximo",
        "data": "17:36 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:37 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "17:37 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B é melhor",
        "data": "17:38 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:38 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:38 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hmmmmmmmmmmmmmmmmmmmmmmmmmmm",
        "data": "17:38 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "AAAAAAAAAAAA",
        "data": "17:38 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:38 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
        "data": "17:38 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:39 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:39 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:39 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hm",
        "data": "17:39 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Dificílimo fácil",
        "data": "17:39 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mas claramente dá para ver",
        "data": "17:39 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "AAAAAAAA",
        "data": "17:39 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:40 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:40 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:40 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "parece homen",
        "data": "17:40 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "por isso mesmo k",
        "data": "17:40 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:40 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:40 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:41 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "My god",
        "data": "17:41 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "b parece bem profundo",
        "data": "17:41 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:41 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:41 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:41 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:41 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:41 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "AAAAAAAAAAAAAAA",
        "data": "17:42 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:42 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:42 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "parece sangue atrás além da pose aerodinâmica top",
        "data": "17:42 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:42 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:42 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:43 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:43 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:43 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera é mesma",
        "data": "17:43 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "top",
        "data": "17:43 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:43 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:43 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bot?",
        "data": "17:43 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ata",
        "data": "17:43 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:43 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:44 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:44 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:44 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:44 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa",
        "data": "17:44 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "agora to morto",
        "data": "17:44 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:44 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:44 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:44 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q sapeca",
        "data": "17:44 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:44 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:44 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:45 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:45 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:45 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:45 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "parece meu estilo",
        "data": "17:45 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A é mais picante b é mais éx",
        "data": "17:45 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "prefiro A",
        "data": "17:45 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:46 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:46 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:46 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:46 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B parece bem agresalhada",
        "data": "17:46 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:46 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:46 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:46 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:46 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:46 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:47 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:47 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B é mais yse",
        "data": "17:47 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:47 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:47 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "intelectuais vs. depressions",
        "data": "17:47 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:47 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:47 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:48 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:48 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:48 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:48 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:48 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B parece mais não inocente",
        "data": "17:48 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:48 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:48 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa to morto",
        "data": "17:48 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B pois q unha em",
        "data": "17:49 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:49 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:49 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:49 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:49 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:49 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds to morto já",
        "data": "17:49 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mas pensando bem",
        "data": "17:49 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "diretamente A",
        "data": "17:49 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:49 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:49 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "17:50 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds tem uma qqqqqqqq na cabeça",
        "data": "17:50 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:50 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:50 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:50 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "My god duas irmãzinhas",
        "data": "17:51 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:51 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:51 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:51 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:51 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:51 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hmmmmmmm",
        "data": "17:51 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B tem dificuldades no sentimento",
        "data": "17:51 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:51 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:52 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:52 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "garota vs mulher",
        "data": "17:52 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:52 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:52 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:52 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "3x seguidas a mema",
        "data": "17:52 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:52 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:52 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:52 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa",
        "data": "17:52 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:53 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:53 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B nem parece inocente em",
        "data": "17:53 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:53 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:53 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:53 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hmmmmmmmmmmmmmmmmmm",
        "data": "17:53 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:53 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:53 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:53 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:53 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:53 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:54 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "17:54 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "4x seguidas",
        "data": "17:54 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:54 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:54 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:54 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:54 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:54 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:54 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa parece eu quando to B",
        "data": "17:55 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:55 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:55 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:55 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:55 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B parece profundo",
        "data": "17:55 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:55 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:55 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:55 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "KANA ARIMA!!!!!!!!!!!!!!!!!!!!!!!",
        "data": "17:55 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx",
        "data": "17:55 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "calma",
        "data": "17:56 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A parece meio clima pesado",
        "data": "17:56 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:56 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:56 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:56 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:56 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:57 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hmm",
        "data": "17:57 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:57 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:57 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:57 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:57 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hmm",
        "data": "17:57 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:58 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:58 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:58 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "são irmãs?",
        "data": "17:58 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa",
        "data": "17:58 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:58 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:58 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "17:58 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A parece bem madura",
        "data": "17:59 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:59 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:59 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "AA?",
        "data": "17:59 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "17:59 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:59 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "17:59 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "17:59 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa",
        "data": "18:00 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "agora dificilmente não lasco",
        "data": "18:00 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:00 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:00 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:00 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:00 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:00 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:00 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:00 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aquela parte de baixo parece um homi em",
        "data": "18:01 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:01 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:01 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:01 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:01 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:01 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:01 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:01 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:01 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:01 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ela tem um relógio no olho?",
        "data": "18:01 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tempo?",
        "data": "18:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa",
        "data": "18:02 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A foi a mais próxima até agora",
        "data": "18:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera nem tá próxima",
        "data": "18:02 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "boa",
        "data": "18:03 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:03 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mai god uma piscadela",
        "data": "18:03 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Agora a polícia vem -18 e +18",
        "data": "18:03 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A parece mais inocente",
        "data": "18:03 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:03 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:03 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A é bem sentimenta",
        "data": "18:04 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:04 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "5x",
        "data": "18:04 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:04 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:04 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A parece bem depressiva",
        "data": "18:04 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:04 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:04 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:05 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:05 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:05 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "/waifu",
        "data": "18:05 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "18:05 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bot?",
        "data": "18:05 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:05 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ata",
        "data": "18:05 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:05 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:05 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "próxima em",
        "data": "18:05 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quase 50% meu tipo",
        "data": "18:05 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:05 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:06 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:06 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:06 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:06 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:06 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hmmmmmmmmmmmmmmmmmmmmm",
        "data": "18:06 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa to sendo seduzido",
        "data": "18:06 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:06 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:06 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:07 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:07 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:07 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:07 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:07 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tá me sacaneiando pela mão no rosto é?",
        "data": "18:07 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:07 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:07 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:08 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:08 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B parece mais tranquila",
        "data": "18:08 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:08 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:08 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:08 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:08 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:08 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:09 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A parece tar agradecida",
        "data": "18:09 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:09 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:09 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:09 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A parece bem rapa",
        "data": "18:09 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "b",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "6x seguidsa",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:10 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:11 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:11 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:11 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:11 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:11 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:11 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:11 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hmmmmmm",
        "data": "18:11 de 06/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@647798629641224192> has reached level **9**. GG!",
        "data": "18:11 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:11 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:11 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:11 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:12 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:12 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:12 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:12 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:12 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:12 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:12 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:12 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:12 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "elá tá me abraçando?",
        "data": "18:13 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "18:13 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:13 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:13 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:13 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:13 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:13 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:13 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:13 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:14 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:14 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "A",
        "data": "18:14 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:14 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:14 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "",
        "data": "18:14 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "B",
        "data": "18:15 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho que já deu",
        "data": "18:15 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "proximo",
        "data": "18:15 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "18:17 de 06/05/2024"
    },
    {
        "user": "AI Image Generator#8424",
        "mensagem": "<@647798629641224192> your image has been generated!",
        "data": "18:17 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "18:17 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "18:18 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "my god",
        "data": "18:18 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "MDS",
        "data": "18:18 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "18:18 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "desde quando?",
        "data": "18:18 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "18:18 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "18:18 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "mas oq é isso em burn",
        "data": "18:18 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nda n",
        "data": "18:18 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "18:18 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "hmmmmmmmmmmm",
        "data": "18:18 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "my gooooooooooood",
        "data": "18:18 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "q quiz ne",
        "data": "18:18 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pedra tá bem criativa no unbeliable em",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q?",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vá pescar q se ganha mais",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "Virtual Fisher#7036",
        "mensagem": "",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "até outro maior",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ">)",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "um pouco maior",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@647798629641224192>",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera sou eu",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora oq",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "?",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@674267691627839510> has reached level **4**. GG!",
        "data": "18:19 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sla",
        "data": "18:20 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "18:20 de 06/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "18:20 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora gartic discrod",
        "data": "18:20 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "how?",
        "data": "18:20 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "18:20 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "how?",
        "data": "18:20 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "how?",
        "data": "18:20 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "how?",
        "data": "18:20 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "how?",
        "data": "18:20 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "se lembra",
        "data": "18:20 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "se consegue",
        "data": "18:20 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "im not gay",
        "data": "18:20 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "18:20 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q q era",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "o comando",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "qual modo",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tem modo?",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vai clássico",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "gb.gartic",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "barco",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "capitão",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "naufraga",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "náufrago",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "cachimbo",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "piloto",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "como escreve isso",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tripulante",
        "data": "18:21 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nem eu sei",
        "data": "18:22 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "embarcador",
        "data": "18:22 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "a",
        "data": "18:22 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "n sei oq cois",
        "data": "18:22 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pula",
        "data": "18:22 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "se consegue",
        "data": "18:22 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "gb.pular",
        "data": "18:22 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "18:22 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "18:22 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "18:22 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ata",
        "data": "18:22 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "18:22 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "18:22 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "18:22 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:23 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "18:23 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora outro",
        "data": "18:23 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora oq?",
        "data": "18:23 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "q",
        "data": "18:23 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "oq",
        "data": "18:23 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "18:23 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "qual era o nome mesmo?",
        "data": "18:23 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "18:23 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "não da resposta",
        "data": "18:23 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kirka!",
        "data": "18:23 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kirks?",
        "data": "18:24 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "18:24 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quase acertei",
        "data": "18:24 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "18:24 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": ":arrows_counterclockwise: Digite **gb.reiniciar** para começar uma nova partida!",
        "data": "18:24 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho q perdi a conta",
        "data": "18:25 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "18:25 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que perdi",
        "data": "18:25 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": ":arrows_counterclockwise: Digite **gb.reiniciar** para começar uma nova partida!",
        "data": "18:26 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho q no sei",
        "data": "18:26 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "18:26 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "onde fica?",
        "data": "18:26 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sla",
        "data": "18:26 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "manda ae",
        "data": "18:27 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": ":arrows_counterclockwise: Digite **gb.reiniciar** para começar uma nova partida!",
        "data": "18:28 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "a",
        "data": "18:28 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quase fui trolado",
        "data": "18:28 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quase",
        "data": "18:28 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "18:29 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mande",
        "data": "18:29 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "now",
        "data": "18:29 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "@",
        "data": "18:29 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bia",
        "data": "18:29 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "18:29 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "oq",
        "data": "18:29 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ja vlt",
        "data": "18:30 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": ":arrows_counterclockwise: Digite **gb.reiniciar** para começar uma nova partida!",
        "data": "18:30 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "gb.reiniciar",
        "data": "18:30 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "18:30 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "gb.finalizar",
        "data": "18:30 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "18:30 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Fala muito oces",
        "data": "19:07 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Slk",
        "data": "19:07 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Baixa a voz ai um pouco",
        "data": "19:07 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "fala isso pro burn ai",
        "data": "19:07 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vc tbm edu",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Fica quietinho ai",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "mas fala isso pro burn",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ai",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "quando",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ele",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "voltar",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "da",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ca",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ga",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "da",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Falou demais",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd?",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "foi mal",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "gb.reiniciar",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Shh",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "mas",
        "data": "19:08 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "fala pro burn ai",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "quando",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "gb.gartic",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ele",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vol",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tar",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "da",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ca",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ga",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "quero n",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "da",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vlw",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Idto",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Idro",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Socando",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Muito",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "verdadeira",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "legitima",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sim",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "gb.pular",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "19:09 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Carteiro",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "como deixar um carteiro triste",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Como q ninguém passou da primeira partida?",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Arará-azul",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "pq reseto",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pássaro azul",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu resetei",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "mordecai",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Gb.finalizar",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "GarticBOT#8088",
        "mensagem": "",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Usa o lord bot ai",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pls",
        "data": "19:10 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Meus slash não funcionar",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sei n mais",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Funciona*",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "como era o comando",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "/iniciar",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Viu",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Nem vai",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bota futebola",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ontem",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Perai",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 10 segundos",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⚠️ Tempo restante: 5 segundos",
        "data": "19:11 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "pule",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "F",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "f",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Tava vendo um treco",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "A partida mais rápida de todas:",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q susto",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Cala boca",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nop",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 10 segundos",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "seis consegue",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Idk",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⚠️ Tempo restante: 5 segundos",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Brasil",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nem eu sei",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bota clássico",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Melhor",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vai burn",
        "data": "19:12 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vdd",
        "data": "19:13 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vai Edu",
        "data": "19:13 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vai oces",
        "data": "19:13 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "coloque o modo bur",
        "data": "19:13 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nop",
        "data": "19:13 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Primeiro as damas",
        "data": "19:13 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vai burn",
        "data": "19:13 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Boa já vlt",
        "data": "19:13 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "jaja ele volta",
        "data": "19:13 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vai edu",
        "data": "19:13 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "pks",
        "data": "19:13 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "pls",
        "data": "19:13 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "se n esqueceu de botar o modo?",
        "data": "19:13 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Não tem como",
        "data": "19:13 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Meu comando slash n funciona",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ata",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Vlw",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "No quarto do idro",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 10 segundos",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Cozinha",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Q",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Raiva",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:14 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "N?",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Netflix",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Help ai efu",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Fome",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@674267691627839510>",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Cê manja",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "bom dia",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bora chega aos 10%",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Do",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Bot",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 10 segundos",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Presidente",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "19:15 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "chama o burn",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Favor edu",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ce manja pow",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "6",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Na china",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "China",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Pq na china não foi",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Injusto",
        "data": "19:16 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Saturno",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Uau",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Foda",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Guarda chuva",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Guarda-chuva",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "<:star_lord:1211158401002905690> <@880817605772967946> acertou!",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 20 segundos",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Eu vou stop",
        "data": "19:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Adedonha",
        "data": "19:18 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 15 segundos",
        "data": "19:18 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "No caso",
        "data": "19:18 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⏱️ Tempo restante: 10 segundos",
        "data": "19:18 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "⚠️ Tempo restante: 5 segundos",
        "data": "19:18 de 06/05/2024"
    },
    {
        "user": "LordBot#3952",
        "mensagem": "",
        "data": "19:18 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "se consegue pedra",
        "data": "19:19 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "stopar o stopido",
        "data": "19:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sefa",
        "data": "19:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Sera",
        "data": "19:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Dps dessa vou agar io",
        "data": "19:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "E eu desisti",
        "data": "19:41 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Agar. io em 2024",
        "data": "20:53 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ctz que em vez de ser jente é bot",
        "data": "20:53 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510> Idro jogava lembra?",
        "data": "20:54 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pera isso era antes do Edu",
        "data": "20:54 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ué é simples se o Edu está a distância é medida pela velocidade da luz então chegará ao nosso passado e verá o idro",
        "data": "20:55 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ">)",
        "data": "20:55 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "qi +1",
        "data": "20:55 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Nunca joguei",
        "data": "20:58 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sera",
        "data": "21:00 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "falando em jogar",
        "data": "21:00 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "bora lethal company falsificado do roblox",
        "data": "21:00 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?",
        "data": "21:00 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Mas eu sei como ele é",
        "data": "21:00 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "nois 4",
        "data": "21:00 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "@everyone",
        "data": "21:00 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "what's the plan for lethal company on roblox? 🎮",
        "data": "21:00 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "cala boca",
        "data": "21:00 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "E eu lembro até hoje do vídeo do AuthenticGames",
        "data": "21:00 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vadio(a)",
        "data": "21:00 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu também",
        "data": "21:00 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Do 1 Milhão",
        "data": "21:00 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Nossa cara que saudades daqueles tempos",
        "data": "21:00 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sera",
        "data": "21:01 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "qq cw acha balde",
        "data": "21:01 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ce vai",
        "data": "21:01 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Topa",
        "data": "21:01 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?",
        "data": "21:01 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Oque",
        "data": "21:02 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ir",
        "data": "21:02 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "lethal company falsificado",
        "data": "21:02 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ata lethal company",
        "data": "21:02 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "do toblox",
        "data": "21:02 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Quero não",
        "data": "21:02 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "roblox",
        "data": "21:02 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "q eu pedi faz umas 300 vezes mês passado",
        "data": "21:02 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "e chegou a um caso não muito agradável",
        "data": "21:02 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "provavelmente possa não acontecer",
        "data": "21:02 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "mas provavelmente é 50% 50%",
        "data": "21:03 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "meio a meio",
        "data": "21:03 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "50/50 é isso",
        "data": "21:03 de 06/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@1054087411359039598> has reached level **2**. GG!",
        "data": "21:03 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Da onde que eu evolui?",
        "data": "21:03 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Só falando é?",
        "data": "21:03 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ent fica ez",
        "data": "21:03 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ao nosso passado",
        "data": "21:03 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "evoluiu",
        "data": "21:03 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ce tá falando de mim e tu <@647798629641224192>",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "balde.",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "O gay foi da a bunda",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "usa @everyone",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Oi pedra",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "wahhh what's going on here?",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "any tea to spill? 🍵",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "@everyone",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "oiieee!",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "🌸 o que vocês tão aprontando? 😊💕",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "pra ti mostra alguma coisa?",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "oshi",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Oi seu cu",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Seu bosta",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "eita que agressividade!",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "😳 o que rolou amigão? 🤔",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "KAKAKAKAKA",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vai toma no seu cu",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Seu bot de merda",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "KAKAKAKAKAKA",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "KAKAKAKAKa",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Pq tu boto a porra de um bot que fala em",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Não quero ser esquizofrênico nao",
        "data": "21:04 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sei la",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Toma no cu <@1134246383587688488>",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "ah tá estressadinho quer um abraço? 🤗",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "kkkkkkkkkkkkkk",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Da um abraço na sua mãe aquela gorda",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "nossa que agressividade precisa de um chill pill? 😂",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Só se for no seu rabo",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "eita que baixaria vamos manter a paz 🕊️",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "fala dboa com ela",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ela?",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "na paz",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "ELA",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ele",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Essa desgraça nem gênero tem",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sei la",
        "data": "21:05 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vai manter essa paz lá em Rio de Janeiro",
        "data": "21:06 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "haha o que tá rolando aqui hein? 🤣🤣🤣",
        "data": "21:06 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Pq aqui ce não vai consegui",
        "data": "21:06 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Toma no cu porra",
        "data": "21:06 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ok parei com meu show",
        "data": "21:06 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vdd",
        "data": "21:06 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Deixa eu ver se esse bot funciona mesmo",
        "data": "21:06 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "o Brasil pão bom vai te contaminar um dia",
        "data": "21:07 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "<@1134246383587688488> Oque é que aumenta 10× o seu tamanho quando estimulado",
        "data": "21:07 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "uma esponja! 🤣🤣🤣",
        "data": "21:07 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Não porra",
        "data": "21:07 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Achei que ele ia fala pupila",
        "data": "21:07 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "A mas eu tmb não especifiquei",
        "data": "21:07 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Mas tá certo",
        "data": "21:08 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "<@1134246383587688488> em que data acabou a segunda guerra mundial",
        "data": "21:08 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "parece que alguém não está com sorte hoje hein? 😂",
        "data": "21:08 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vish",
        "data": "21:08 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Já tem um erro já",
        "data": "21:08 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "E pq ele fala de uma forma tão sarcástica em pedra",
        "data": "21:08 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Eu nem sarcástico sou pedra",
        "data": "21:08 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Acho que se fosse o burn ia ter uma resposta bem melhor que essa",
        "data": "21:09 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "burra dms ne",
        "data": "21:10 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Pse uai",
        "data": "21:10 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vey",
        "data": "21:10 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?",
        "data": "21:10 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Ces tem que para com essa mania de fica botando bot nesse server",
        "data": "21:10 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Olha o tanto de bot",
        "data": "21:10 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "A maioria já tá morto",
        "data": "21:10 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Na vdd só 14",
        "data": "21:11 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "não pow",
        "data": "21:11 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "E 45 estão on",
        "data": "21:11 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Aí é foda",
        "data": "21:11 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Acho que ces tão levando isso muito a sério",
        "data": "21:11 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu e o bruna queriamos botar 1000 membros",
        "data": "21:11 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "com bots",
        "data": "21:12 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Brabo",
        "data": "21:12 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "imagina 1000 bots-",
        "data": "21:12 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Eu nem sei se esse servidor ficaria famoso que nem o burn disse",
        "data": "21:12 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Se tivesse 1000 bot mano",
        "data": "21:12 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "irmão",
        "data": "21:14 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "seria o primeiro server com 1000 bots",
        "data": "21:14 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu acho",
        "data": "21:14 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vdd",
        "data": "21:14 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Acho que teria uma chance de 25% desse server ser reconhecido apenas com 1000 bots",
        "data": "21:15 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "imagina um cara entrando",
        "data": "21:15 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "e vendo q tem mil bots",
        "data": "21:15 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@674267691627839510> has reached level **5**. GG!",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vdd",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "dx eu testar algo",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "E só 50 desses bot funciona",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?math 30+30",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "ghosty#6250",
        "mensagem": "<:calculator:674570908903407617> | **‎‎**, I thought about it and came to the following solution: ```60```",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "E os 950 nem funciona",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ele ya off",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "pera",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "+ban <@458302301187342336>",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "Loritta#0219",
        "mensagem": "🎉 **|** <@880817605772967946> Usuário punido. Ninguém mandou quebrar as regras, seu boboca! <:lori_brava:556525700425711636>",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Que isso",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "valeu",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Loritta tá fera",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "bota outro dps",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vdd",
        "data": "21:16 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "+profile",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "Loritta#0219",
        "mensagem": "",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "OQUE",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "uau",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "shh",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "fala nada vagabundo",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "O CARTÃO DE IDENTIDADE DA PEDRA?!",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@1054087411359039598> has reached level **3**. GG!",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "acho q n",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "@everyone",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "so acho",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "[what's up cutie? who you rizzin' with today? 😘]",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sabe",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "@everyone",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "que isso @idrobilugd1 querendo chamar a galera toda? 🤔",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "@everyone",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "wth why you tagging everyone? chill broski 😂",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Fica quieto aí vai",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "eita tá mandando geral ficar quieto agora hein? 🤭",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "+ban <@1054087411359039598>",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "Loritta#0219",
        "mensagem": "<:error:412585701054611458> **|** <@880817605772967946> Eu não posso punir este usuário, meu cargo é menor que o do usuário a ser punido! Para que eu possa punir, suba o meu cargo para o topo na lista de cargos, obrigada!",
        "data": "21:17 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "filha da puta",
        "data": "21:18 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "k",
        "data": "21:18 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Parei",
        "data": "21:18 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "É só tu apagar aquilo fi",
        "data": "21:18 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "qq ce ta querendo dizer balde",
        "data": "21:18 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?",
        "data": "21:18 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Nada uai",
        "data": "21:18 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Só tô fazendo hora contigo",
        "data": "21:18 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ata",
        "data": "21:18 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu comprei esse banner",
        "data": "21:18 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "por 25k",
        "data": "21:18 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "meu rin e meio",
        "data": "21:18 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "mas ele é foda",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "dms",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu escrevi coisas insanas",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "tipo",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "turi ip",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "+profile",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "Loritta#0219",
        "mensagem": "",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Real",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "duvido tu lembrar",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "de tudo",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "da musica",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ai",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vish nem lembro",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Só essa parte mesmo",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Do Turi Ip",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "burrao",
        "data": "21:19 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Engraçado é a mensagem em cima",
        "data": "21:20 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Não inclua informações como senhas ou número de cartões de crédito em uma mensagem instantânea",
        "data": "21:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "verdade",
        "data": "21:20 de 06/05/2024"
    },
    {
        "user": "Arcane#7800",
        "mensagem": "<@880817605772967946> has reached level **7**. GG!",
        "data": "21:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vou botar o seu idro",
        "data": "21:21 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "+ban <@437808476106784770>",
        "data": "21:21 de 06/05/2024"
    },
    {
        "user": "Loritta#0219",
        "mensagem": "🎉 **|** <@880817605772967946> Usuário punido. Ninguém mandou quebrar as regras, seu boboca! <:lori_brava:556525700425711636>",
        "data": "21:21 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "O meu vai ter nada",
        "data": "21:21 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Nem sonho vou ter k",
        "data": "21:21 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "hm",
        "data": "21:21 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu tenho o meu pelo menos",
        "data": "21:21 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vou botar minha chave pix-",
        "data": "21:21 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Real",
        "data": "21:22 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "euro",
        "data": "21:23 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Engraçado é que o edu tá ausente mas na vdd ele só tá observando tudo",
        "data": "21:23 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "na vdd n",
        "data": "21:23 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ele deve ta",
        "data": "21:23 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "fazendo",
        "data": "21:23 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "coisas",
        "data": "21:23 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "q eu nao know",
        "data": "21:23 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sabr",
        "data": "21:23 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sabe",
        "data": "21:23 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Que tipo de coisas?",
        "data": "21:23 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "coisas",
        "data": "21:23 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Coisas coisadas?",
        "data": "21:23 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu acho q o edu me infectou demais",
        "data": "21:24 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Pq mano?",
        "data": "21:24 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu to começando a virar ele",
        "data": "21:24 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "olha como eu digitei",
        "data": "21:24 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Real",
        "data": "21:24 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Vou ter que matar o edu só por causa disso",
        "data": "21:24 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ne nao",
        "data": "21:25 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "usa vacina anti-idroxido",
        "data": "21:25 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Pq ce não disse antes em ghay",
        "data": "21:25 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "pq eu inventei",
        "data": "21:26 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "provavelmente ta por ai",
        "data": "21:26 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sabe",
        "data": "21:26 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Aham",
        "data": "21:29 de 06/05/2024"
    },
    {
        "user": "idrobilugd1",
        "mensagem": "Sei",
        "data": "21:29 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sabe",
        "data": "21:31 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "porra e essa",
        "data": "21:31 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sei edu",
        "data": "21:32 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu voltei",
        "data": "21:37 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu voltei",
        "data": "22:08 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu voltei",
        "data": "22:13 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tu oq?",
        "data": "22:13 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ele voltou",
        "data": "22:13 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "voltou de onde?",
        "data": "22:13 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Da volta ué",
        "data": "22:14 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tudo que volta vai embora",
        "data": "22:14 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "e tudo q vai?",
        "data": "22:14 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Se foi F",
        "data": "22:14 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "22:15 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tudo que não vai embora retorna?",
        "data": "22:16 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ah então quer dizer que a ida é a mesma da viagem",
        "data": "22:16 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ah então é por isso que quando andamos voltamos para casa?",
        "data": "22:16 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ah",
        "data": "22:16 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510> Ta certo isso?",
        "data": "22:16 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "se nois andar em linha reta tudo da na nossa casa de volta",
        "data": "22:17 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd bem que o Globo é redondo",
        "data": "22:17 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "22:17 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Acho q s",
        "data": "22:17 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "22:17 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hm",
        "data": "22:18 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Acho q s",
        "data": "22:18 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pois se chutar uma bola e ela não rodar então ela tá parada",
        "data": "22:18 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Que exemplo demonstrativo",
        "data": "22:18 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pera se ela continua rodando então a terra é plana",
        "data": "22:18 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "meu ta piscando",
        "data": "22:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Rapa im antigloboterraplabistas",
        "data": "22:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vish",
        "data": "22:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Né",
        "data": "22:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "o \"cu\" não saiu",
        "data": "22:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "J",
        "data": "22:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "provavelmente eu esqueci de escreve",
        "data": "22:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Corretor?",
        "data": "22:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "bruna falando nada com nada",
        "data": "22:19 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "slk",
        "data": "22:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nop",
        "data": "22:19 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "22:19 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ele tem",
        "data": "22:19 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Olha a terra se ela não for redonda ela não é",
        "data": "22:19 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ou tem",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ele tem",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "n sabo",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "se saba?",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tu tienes?",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu seba",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tens?",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sapato",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ele tem",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu tenho sapatênis",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tem?",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "nah",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "Ele",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vixi",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ele tem?",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ele pow",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ele ali",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ta vendo",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "entao ele tem?",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sim",
        "data": "22:20 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "nossa",
        "data": "22:21 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "minha nossa nossa nossa",
        "data": "22:21 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "mas o oto ali tbm tem",
        "data": "22:21 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ele tem entao",
        "data": "22:21 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "aquele ali",
        "data": "22:21 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "aquele?",
        "data": "22:21 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sim",
        "data": "22:21 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ele e ele",
        "data": "22:21 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sim sim",
        "data": "22:21 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ele e ele entao",
        "data": "22:21 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eles 2 ali tem",
        "data": "22:21 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sim sim",
        "data": "22:21 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ata",
        "data": "22:21 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera q eles tao usando",
        "data": "22:21 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "acho q n",
        "data": "22:22 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "se tu perceber",
        "data": "22:22 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ele ali ta sandalia",
        "data": "22:22 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "o outro da de crocs da nike",
        "data": "22:22 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "na cor lgbtqiapm",
        "data": "22:22 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "++",
        "data": "22:22 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "e o de crocs ta com aqueles negocio de botar em crocs?",
        "data": "22:23 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "nao pow",
        "data": "22:23 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ali e o outro",
        "data": "22:23 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "é aquele",
        "data": "22:23 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "mes tem ou ouve",
        "data": "22:23 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "e o crocs ta com a alça pra tras ou pra frente?",
        "data": "22:23 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ele ta com a alça pra o meio dia invertido",
        "data": "22:24 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "pro meio dia de la ou pra ca",
        "data": "22:24 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "pro meio dia a esquerda invertida",
        "data": "22:24 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "de dentro ou de fora?",
        "data": "22:24 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ta pra fora pelo visto",
        "data": "22:25 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu acho",
        "data": "22:25 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "se acha?",
        "data": "22:25 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ta em 45 , 90 ou 152,0912344230 graus?",
        "data": "22:25 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "quase isso",
        "data": "22:25 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "mas ta invertido",
        "data": "22:25 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "acho q e so questão de ângulo",
        "data": "22:25 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "de cores verdadeiras triangulares?",
        "data": "22:26 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "acho q n",
        "data": "22:26 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "entao cores falças  triangulares?",
        "data": "22:26 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "isso ai",
        "data": "22:30 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "na moca",
        "data": "22:31 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "mosca",
        "data": "22:31 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "moscada",
        "data": "22:31 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Jente do céu teve um mosquito aqui com uma picada tão forte que tive até que levantar para ver",
        "data": "22:43 de 06/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vô até trocar de coberta",
        "data": "22:44 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ce gosta de levar picada forte?",
        "data": "22:49 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "mano",
        "data": "22:50 de 06/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "mano",
        "data": "22:52 de 06/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "acho q sim",
        "data": "01:14 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds",
        "data": "07:10 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkkkkkk",
        "data": "07:10 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkk",
        "data": "07:12 de 07/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "wassup nikyrie? what's crackin' on your end? 🌟",
        "data": "07:12 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hm",
        "data": "07:13 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@1134246383587688488> bu",
        "data": "07:13 de 07/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "what's good buddy?",
        "data": "07:13 de 07/05/2024"
    },
    {
        "user": "Nurmonic#8961",
        "mensagem": "what's all this about? 😂",
        "data": "07:13 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@1134246383587688488> oh",
        "data": "07:13 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Serious",
        "data": "07:14 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Vdddd",
        "data": "09:52 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "pra o edu a noite é dia",
        "data": "12:13 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "slk",
        "data": "12:13 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "rpg rd",
        "data": "15:07 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "uai",
        "data": "15:07 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "baniram o coitado",
        "data": "15:07 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "certeza",
        "data": "15:07 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "pronto",
        "data": "15:08 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@647798629641224192>",
        "data": "15:08 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "bora dungeon",
        "data": "15:08 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Dnv",
        "data": "15:17 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "espera 1 mês",
        "data": "15:17 de 07/05/2024"
    },
    {
        "user": "Nekotina#0608",
        "mensagem": "Página **3** de **17**",
        "data": "15:18 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera a foto é mesma",
        "data": "15:18 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "a",
        "data": "15:18 de 07/05/2024"
    },
    {
        "user": "Nekotina#0608",
        "mensagem": "Página **1** de **61**",
        "data": "15:18 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "15:18 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vai lá idro",
        "data": "15:22 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Vdd",
        "data": "15:49 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Ele já foi",
        "data": "15:50 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "já?",
        "data": "15:50 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Ja",
        "data": "15:50 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa",
        "data": "15:50 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "olha quem retornou",
        "data": "15:50 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "F quem retornou",
        "data": "15:50 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "já sei",
        "data": "15:51 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:51 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora roblox",
        "data": "15:51 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Burn e suas waifu",
        "data": "15:51 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Pera",
        "data": "15:51 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "15:51 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ata",
        "data": "15:51 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "bom dia",
        "data": "15:51 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ue eu tenho uma playlist",
        "data": "15:51 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah to na conta errado",
        "data": "15:52 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "eae",
        "data": "15:52 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "eae",
        "data": "15:52 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho que meu autenticador tá meio seguro",
        "data": "15:52 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "e oq?",
        "data": "15:52 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "perae que nem abri",
        "data": "15:53 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "15:53 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "estrela?",
        "data": "15:53 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa mudo em",
        "data": "15:53 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "15:53 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "né",
        "data": "15:53 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "d+",
        "data": "15:54 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "porque mudaram a fonte k",
        "data": "15:54 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sla",
        "data": "15:54 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "e bora oq",
        "data": "15:54 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "oq",
        "data": "15:54 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "oq",
        "data": "15:54 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "oq",
        "data": "15:54 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "oq",
        "data": "15:54 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "oq",
        "data": "15:54 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "oq",
        "data": "15:54 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "oq",
        "data": "15:54 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "calma",
        "data": "15:54 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx",
        "data": "15:54 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "eu to vendo as atualizaqções",
        "data": "15:54 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds quanto novo",
        "data": "15:55 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nosso tudo veio",
        "data": "15:55 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "idro tá meio perto",
        "data": "15:55 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho mais fácil nois testa um novo",
        "data": "15:56 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "e pq tu n viu o mey",
        "data": "15:56 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "meu*",
        "data": "15:56 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510> né vdd?",
        "data": "15:56 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "15:57 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "yes",
        "data": "15:57 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "net top",
        "data": "15:57 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "meymar?",
        "data": "15:57 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "+ban <@429457053791158281>",
        "data": "15:57 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "s",
        "data": "15:57 de 07/05/2024"
    },
    {
        "user": "Loritta#0219",
        "mensagem": "🎉 **|** <@880817605772967946> Usuário punido. Ninguém mandou quebrar as regras, seu boboca! <:lori_brava:556525700425711636>",
        "data": "15:57 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ce ja viram a bomba e o einstein?",
        "data": "15:57 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "bao dms",
        "data": "15:57 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "recomendo",
        "data": "15:57 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "o einsten usava bomba?",
        "data": "15:57 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho q s",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "bomba  estenio",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "e*",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vei era bombado",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "slk",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "bombou",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "rpg duel <@647798629641224192>",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q peninha",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "mutaram dnv",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "putz",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "coitado",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "foi o burn",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "k",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "foi ele",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sera",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "15:58 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "foi o burning",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "baniram",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "quem baniu",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "o burn",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que fui eu?",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho q no em",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "estás duvidando?",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "plmds tere",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "pq baniu ele",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ele te fez nada",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa edu",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "15:59 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "foi",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah vdd",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será?",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "edu baniu pow",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera?",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "será?",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sare?",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sáre",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sáre?",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tô até agora tentando escolher um k",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "burn escolhas",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que é levinho?",
        "data": "16:00 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sim sim",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "q pena",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ele voltou",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ne",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ne",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ne",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ne",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ne",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ne",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ne",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ne",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mai god",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ne?",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vdd",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "29",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "rpg duel <@647798629641224192>",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "quem",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "quem",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "QUEM",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "perfect",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "QUEEEEEEEEEEEEEEEEEEEM",
        "data": "16:01 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "?",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "1",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "a 8",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "mais de 0,1",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ou sera q n",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "parece bem sorridente",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "bem",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ate d+",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "né",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aplicaram um :thermal ali k",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "16:02 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "se lembra?",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "no",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "eu acho q ele voltou",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "lembra oq?",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "so acho",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "sabe",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "<@555955826880413696>",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "viu",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "lembra da lentidão mds",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "so acho mesmo sabe",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "jaja acaba",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vc acha?",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vdd",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "jajá",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "deve ja tar em 99%",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "espera um tempin",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tá quase",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "errou",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "99,9%",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "foi",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "99,9991%",
        "data": "16:03 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ta em 70.999999999999899999998%",
        "data": "16:04 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera que tá configurando",
        "data": "16:04 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "100%",
        "data": "16:04 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ala",
        "data": "16:04 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "rapidao",
        "data": "16:04 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ne",
        "data": "16:04 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "acertei centim",
        "data": "16:04 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "nem vi antes",
        "data": "16:04 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "agora inicializando",
        "data": "16:04 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ae",
        "data": "16:04 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "foi foi",
        "data": "16:04 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "vdd",
        "data": "16:04 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "hotdogo",
        "data": "16:04 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho q não lembro como era o pv no",
        "data": "16:04 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "tenta lembrar",
        "data": "16:05 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "é facin",
        "data": "16:05 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "rlx",
        "data": "16:05 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "eu acho q nunca fui esse",
        "data": "16:05 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "esse qual",
        "data": "16:05 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "esse",
        "data": "16:05 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "esse ali?",
        "data": "16:05 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "esse ali",
        "data": "16:05 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ata",
        "data": "16:05 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "pensei q era esse aq",
        "data": "16:05 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "era aquele",
        "data": "16:05 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "aquele?",
        "data": "16:05 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "isso isso isso",
        "data": "16:06 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "baguetoide",
        "data": "16:06 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "🍆",
        "data": "16:07 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "berinjola",
        "data": "16:07 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "🍍",
        "data": "16:08 de 07/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "16:08 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "acaboxi",
        "data": "16:08 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "154 mil moedas",
        "data": "16:08 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "muito",
        "data": "16:08 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "demora",
        "data": "16:08 de 07/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "16:08 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "ata",
        "data": "16:08 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "so isso",
        "data": "16:08 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "rpg rd",
        "data": "16:09 de 07/05/2024"
    },
    {
        "user": "EPIC RPG#4117",
        "mensagem": "",
        "data": "16:09 de 07/05/2024"
    },
    {
        "user": "dyy_die",
        "mensagem": "q",
        "data": "16:09 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho q net top",
        "data": "16:20 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "16:22 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "poker no roblox mds",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nem eu sei",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510> se sabe?",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "n sei",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "mas n saber oq?",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "saber jogar poker",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "obvius",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "se sabe?",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "nunca nem vi",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "boa",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que nois aprende?",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "claro",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "claro kk",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "16:23 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será melhor pesquisar?",
        "data": "16:24 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ou na marra?",
        "data": "16:24 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "na marra",
        "data": "16:24 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ou talvez",
        "data": "16:24 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ótimo",
        "data": "16:24 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "pesquisa ai burn e me ensine em menos de 1 min",
        "data": "16:24 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q q é endossamos",
        "data": "16:25 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ok",
        "data": "16:25 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "um animal quadrado de lego",
        "data": "16:25 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah",
        "data": "16:25 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd?",
        "data": "16:25 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "16:26 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tem mãos",
        "data": "16:26 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "parece ez",
        "data": "16:26 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "nem tem server vip",
        "data": "16:26 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "resumindo quanto mais próximo do Às",
        "data": "16:27 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "melhor",
        "data": "16:27 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd?",
        "data": "16:27 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tenta outro ae",
        "data": "16:27 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "quanto maior ou menos entao?",
        "data": "16:27 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "só +",
        "data": "16:27 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "esse tem",
        "data": "16:27 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "cria ai",
        "data": "16:28 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "agora q sai do outro",
        "data": "16:28 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "16:28 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "basatnte",
        "data": "16:28 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "4 perfect",
        "data": "16:28 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "entra ae",
        "data": "16:29 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aliás se pegar duas cartas repetidas tá melhor",
        "data": "16:29 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "kk",
        "data": "16:41 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "quando tu saiu o teu coisa saiu andando",
        "data": "16:41 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "16:42 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "da mesa",
        "data": "16:42 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tipo quando entra mais ao contrario",
        "data": "16:43 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah",
        "data": "16:44 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "caraca bot se mutou",
        "data": "16:44 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "16:44 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "bora oq",
        "data": "16:44 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mai god",
        "data": "16:44 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "osu na roblox",
        "data": "16:45 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "boa",
        "data": "16:45 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera calma",
        "data": "16:45 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx",
        "data": "16:45 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "o jogo n atualiza a 10 anos pra atualizar top d+",
        "data": "16:46 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "16:46 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "burn escolhas",
        "data": "16:46 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tops",
        "data": "16:47 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "d",
        "data": "16:47 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "mais",
        "data": "16:47 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "eu to pensando em como não to recenbo a notificação do discord estando desmutado",
        "data": "16:48 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah",
        "data": "16:48 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa",
        "data": "16:48 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "boa",
        "data": "16:49 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q q eu escolho",
        "data": "16:52 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "a escolha",
        "data": "16:52 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "achei",
        "data": "16:54 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "boa",
        "data": "16:55 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "16:55 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ja vlt",
        "data": "16:58 de 07/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Esqueci de voltar k",
        "data": "21:14 de 07/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Percebi",
        "data": "03:59 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "E se volta as 4",
        "data": "06:57 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Como vou clicar no canal",
        "data": "08:46 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "08:46 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q demora",
        "data": "08:46 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Já já envia",
        "data": "09:52 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "1 arquivos",
        "data": "13:29 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "1.00000000000000000000000000000000000000000000...",
        "data": "13:34 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q grande",
        "data": "13:34 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "top 1 duplos sentidos",
        "data": "13:55 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que o cll do burn é um tablet?",
        "data": "13:55 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "13:56 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera q é 1 tablets",
        "data": "13:56 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será?",
        "data": "13:56 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "cara eu to suando por calor",
        "data": "13:56 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q raro",
        "data": "13:56 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "já sei",
        "data": "13:57 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@647798629641224192>",
        "data": "13:57 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera",
        "data": "13:57 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "13:57 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora",
        "data": "13:57 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera q",
        "data": "13:57 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "eu havia abrido roblox e o fechei dai abri o discord e agora lembrei que desconectei da roblox",
        "data": "13:57 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "modo automático mais seguro do mundo",
        "data": "13:57 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "how",
        "data": "13:58 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "how",
        "data": "14:00 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa acho q depois dessa nunca mais vou no banheiro durante uma semana",
        "data": "14:18 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pela primeira vez mais de 20 minutos no banheiro",
        "data": "14:19 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vou idrar",
        "data": "14:19 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vlt",
        "data": "17:08 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "o tradutor traduziu para inglês",
        "data": "17:08 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q legal",
        "data": "17:08 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera se o tradutor é originalizado em inglês então nós que somos traduzidos",
        "data": "17:15 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "my god eu traduzi meus pensamentos em uma língua estrangeira",
        "data": "17:15 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mano o que é idiossincrasias",
        "data": "20:31 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Aí tá complexa até d+",
        "data": "20:32 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ou formal",
        "data": "20:32 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Depende do Edu",
        "data": "20:32 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "20:32 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será que eles percebem que usei chat GPT?",
        "data": "20:33 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Acho q no em",
        "data": "20:33 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "21:30 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd duas vezes",
        "data": "21:30 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tive uma ideia",
        "data": "21:33 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Hehe",
        "data": "21:33 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Perfect",
        "data": "21:33 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:34 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:34 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:34 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:34 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:34 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:34 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:35 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:35 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:35 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:35 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:35 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:35 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:36 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:36 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:36 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:36 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quanta vdd",
        "data": "21:37 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "21:38 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "21:38 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Acho q s",
        "data": "21:38 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pior que se ler em sequência dá certinho",
        "data": "21:39 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Burn é um genius",
        "data": "21:39 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "21:39 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ctz que com migo aqui ninguém pega depressão",
        "data": "21:41 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Com migo?",
        "data": "21:41 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Comigo?",
        "data": "21:41 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Umbigo?",
        "data": "21:41 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "21:42 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Guyuq?",
        "data": "21:42 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ah sim",
        "data": "21:42 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Agora tô vendo",
        "data": "21:42 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "21:43 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "aham",
        "data": "21:43 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "uguey",
        "data": "21:43 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "21:44 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será que o pessoal é atualizado poco?",
        "data": "21:45 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será?",
        "data": "21:46 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sla",
        "data": "21:46 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "De pesquisa o Server ae",
        "data": "21:47 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nossa o nome",
        "data": "21:47 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q Perfect++",
        "data": "21:47 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ctz que é um dos comentados ultimamente",
        "data": "21:47 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mentira que o discord termina com gg",
        "data": "21:48 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Para onde vai esse link?",
        "data": "21:48 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "https://discord.gg/hTKzmak",
        "data": "21:49 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "21:49 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ah",
        "data": "21:49 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "21:50 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Acho q n",
        "data": "21:50 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "21:50 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Acho q s",
        "data": "21:50 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "21:50 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Acho q tô realmente achando",
        "data": "21:50 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tô sendo derrotado por uma sequência vitalícia de palavras repetidas",
        "data": "21:51 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "21:52 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será que o Edu é direto?",
        "data": "21:52 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "21:52 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ctz que eu não falo d+",
        "data": "21:52 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Até o corretor tá virando burn",
        "data": "21:53 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Perae vô fazer o teste",
        "data": "21:53 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "21:53 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "My god",
        "data": "21:53 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "k",
        "data": "21:54 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Rapa",
        "data": "21:54 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Já sei",
        "data": "21:55 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tenho n",
        "data": "21:55 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "21:55 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pera que vou passar o nome",
        "data": "21:56 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "convida ele la",
        "data": "21:56 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Melhor não",
        "data": "21:56 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ele é bem inocente",
        "data": "21:56 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pera só tem como adicionar convocando e não metendo direto aqui?",
        "data": "21:56 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "s",
        "data": "21:57 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vou convocar o zue >)",
        "data": "21:57 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Achei o nome dele",
        "data": "21:58 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tenta ae",
        "data": "21:58 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Aqui",
        "data": "21:58 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Melhor",
        "data": "21:59 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mais zoom",
        "data": "21:59 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pera como ele vai aceita se ele tá silencioso?",
        "data": "22:00 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "a",
        "data": "22:00 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "faz magica",
        "data": "22:00 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Unidumeminguesalamenmingue?",
        "data": "22:00 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Já sei",
        "data": "22:01 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Rlx que ele vem com o poder das palavras",
        "data": "22:01 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Já sei",
        "data": "22:01 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Perfecf",
        "data": "22:01 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "22:02 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Que específico",
        "data": "22:02 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pera vdd?",
        "data": "22:02 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "22:02 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "um bioma",
        "data": "22:02 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será?",
        "data": "22:02 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Bate bem",
        "data": "22:02 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quase igual o nome",
        "data": "22:03 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "My god",
        "data": "22:04 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Uma lei municipal com o nome do zue kkkkk",
        "data": "22:04 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "My god",
        "data": "22:05 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Zue é uma zona especial kkkkkkkk",
        "data": "22:05 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Viu só Edu",
        "data": "22:06 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "22:07 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd?",
        "data": "22:07 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Óbvius",
        "data": "22:07 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkkkkkkkk",
        "data": "22:07 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nossa agora que tô sabendo vou pesquisar 5000000 prints e mandar para ele kkkkk",
        "data": "22:07 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Acho que eu tiro umas 30 prints por dia com desvio de 0 a +100",
        "data": "22:09 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "22:10 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tenho até foto do meu olho no dia mais sensível que esteve k",
        "data": "22:10 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "menos",
        "data": "22:11 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nossa",
        "data": "22:11 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds quantas?",
        "data": "22:11 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Umas zero fotos por semanas?",
        "data": "22:11 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "22:11 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "-0 por dia",
        "data": "22:12 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ah tá de boa",
        "data": "22:12 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Quase",
        "data": "22:12 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "talvez",
        "data": "22:14 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Que duplo sentido top",
        "data": "22:14 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds já é 22 horas",
        "data": "22:15 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Devia tar conversando mais",
        "data": "22:15 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "22:15 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Óbvius",
        "data": "22:15 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será que sou a definição de extroversão?",
        "data": "22:16 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "93% não é muito né",
        "data": "22:16 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Em comparação com os tímidos 7% né?",
        "data": "22:16 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "22:17 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "22:20 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Idro previu isso desde quatro meses atrás",
        "data": "22:21 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ninguém viu nada",
        "data": "22:21 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Tirando a edição nadica de nada",
        "data": "22:21 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "aham",
        "data": "22:21 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Oh no",
        "data": "22:22 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Edu aham é muito simpático",
        "data": "22:22 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "aham",
        "data": "22:22 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "My god",
        "data": "22:22 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Perae que vou ir",
        "data": "22:23 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Senão não durmo k",
        "data": "22:23 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "22:23 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Zue se coloca uma hora e vira o máximo k",
        "data": "22:23 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ficar acordado tem relação com não dormir?",
        "data": "22:24 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nossa",
        "data": "22:24 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pior que faz sentido",
        "data": "22:24 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "nao",
        "data": "22:25 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nossa",
        "data": "22:25 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Pesou meu coração",
        "data": "22:25 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Edu me destruiu com uma palavra k",
        "data": "22:25 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "não",
        "data": "22:25 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Não",
        "data": "22:25 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Aí mds",
        "data": "22:25 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Stop",
        "data": "22:25 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "NÃO",
        "data": "22:26 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "My god",
        "data": "22:26 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Melhor eu ir",
        "data": "22:26 de 08/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Não volto k",
        "data": "22:26 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "NAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAÃOOOOOOOOOOOOOOOOOOOOO",
        "data": "22:26 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "22:26 de 08/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "real",
        "data": "00:40 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera q ele ainda volta",
        "data": "00:40 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "01:33 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sei n em",
        "data": "01:54 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Talvez",
        "data": "02:38 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Vdd",
        "data": "06:46 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "06:47 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Só em não sem acento burn já tem mais de 1000",
        "data": "06:49 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "Pois pois",
        "data": "09:50 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "I win",
        "data": "14:16 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "2",
        "data": "14:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "14:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "1",
        "data": "14:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tive uma ideia",
        "data": "14:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ja vlt",
        "data": "14:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "my god será?",
        "data": "14:43 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "14:43 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será?",
        "data": "14:44 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora mecher com banco de dados >)",
        "data": "14:45 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que um dia vou ser processado?",
        "data": "14:46 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Ah contanto que não seja pego tá ótimo >)",
        "data": "14:46 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vivo?",
        "data": "14:50 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "/histórico",
        "data": "14:51 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "/historico",
        "data": "14:51 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "top",
        "data": "14:51 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "histórico",
        "data": "14:51 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "histórico",
        "data": "14:51 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "top",
        "data": "14:51 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "/histórico",
        "data": "14:51 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah",
        "data": "14:52 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aa",
        "data": "14:52 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "/histórico",
        "data": "14:52 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ok im way",
        "data": "14:53 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "/historico",
        "data": "14:53 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aaaaaaaaa",
        "data": "14:53 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "como o bot tá rodando desligado",
        "data": "14:53 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "/histórico",
        "data": "14:53 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "14:53 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "/histórico",
        "data": "14:55 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "burn tu ta sendo proçeçadu por eletricicar uma cidadi",
        "data": "14:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aaaaaaaaaa",
        "data": "14:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "14:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "im inocent",
        "data": "14:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "top d+",
        "data": "14:55 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "foi tu",
        "data": "14:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "14:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx que sei quem foi",
        "data": "14:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "adivinha quem",
        "data": "14:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ">)",
        "data": "14:55 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "foi tu",
        "data": "14:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "14:56 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ta no teu nomes",
        "data": "14:56 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera q",
        "data": "14:56 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "provas >)",
        "data": "14:56 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera assim vou perde",
        "data": "14:56 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mentiras >)",
        "data": "14:56 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tu ainda queimo 2 cidadi",
        "data": "14:56 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "14:56 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx que é melhor q rlx mesmo",
        "data": "14:57 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "e queimo tbm",
        "data": "14:57 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "14:57 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "top ser so proçeçado por isso",
        "data": "14:57 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "14:57 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tsete 2",
        "data": "14:57 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "/top_histórico",
        "data": "14:57 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "top",
        "data": "14:58 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "/top_histórico",
        "data": "14:58 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aaa",
        "data": "14:58 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "burn ta sendo proçeçadu por negar proçeçu",
        "data": "14:58 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "14:59 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mano meu bot tá on desligado",
        "data": "14:59 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "top",
        "data": "14:59 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ligue oof ele",
        "data": "14:59 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "f",
        "data": "14:59 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa",
        "data": "15:02 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "eu liguei o bot mandar mensagem pra voz",
        "data": "15:02 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "porque será que não tava indo em",
        "data": "15:03 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "agora tá hyper especificado",
        "data": "15:03 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "/top_histórico",
        "data": "15:03 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aaaaaaaa",
        "data": "15:03 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:04 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "posso ligar ele torturinha top?",
        "data": "15:04 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "assim tenho ctz que vai",
        "data": "15:04 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tortuguita pode",
        "data": "15:04 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "só que ele vai ter que passar uma em uma",
        "data": "15:04 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ">)",
        "data": "15:04 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "mas começa pela cabeça ou pelas perna?",
        "data": "15:05 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pelo começo até o fim absoluto",
        "data": "15:05 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ">)",
        "data": "15:05 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "entao n pode",
        "data": "15:05 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx vou limitar em até 0x o poder dele",
        "data": "15:05 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "",
        "data": "15:06 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "eba kk",
        "data": "15:06 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "caraca anti-idro",
        "data": "15:06 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tortuguita",
        "data": "15:06 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "achei ele",
        "data": "15:07 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "15:07 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quase não vi",
        "data": "15:07 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Será que a tortura de bots é o único caminho?",
        "data": "15:08 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:08 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q q se acha?",
        "data": "15:08 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tem que tortuguitar mesmo",
        "data": "15:09 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "né",
        "data": "15:09 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa imagina as futuras gerações com os futuros ditados populares",
        "data": "15:09 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "muito inspiracional",
        "data": "15:09 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vou tentar a prefix \"!\"",
        "data": "15:10 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:10 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "top referências de back",
        "data": "15:10 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "se back é atrás, rooms é sala, então doors é o começo?",
        "data": "15:11 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "doors é uma coisa",
        "data": "15:11 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "portas",
        "data": "15:11 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "abrilas",
        "data": "15:11 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "fechalas",
        "data": "15:12 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "15:12 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sem barras",
        "data": "15:12 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "-",
        "data": "15:12 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "15:12 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "é para ir",
        "data": "15:12 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que vai?",
        "data": "15:12 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "se for ira",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "!top_histórico",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa não tem acneto",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "!top_historico",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "f",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ou sera q n",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "my god",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "nao tera mais acento no mundos",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "maior erro do mundo",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "todo mundo vai ficar em pe",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Têm que have acentos",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "nao tera",
        "data": "15:13 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Nop",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Aíen acentuado",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "levante de sua cadeira",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tô na cadeira nop em",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "top",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "a",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "mas",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "n lembro",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "he",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "he",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "he",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "he",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "he",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "eh",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "e",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "h",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "e",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "eh",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "eh",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "he",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "he",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ehe",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "eh",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "e",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "eh",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "eh",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ehhee",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ehehee",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ehe",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "he",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "eu realmente queria saber como o erro foi no site do awari",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "indo",
        "data": "15:14 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "how",
        "data": "15:15 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "o ip caiu lá",
        "data": "15:15 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tire de la",
        "data": "15:15 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "how",
        "data": "15:15 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tirando",
        "data": "15:15 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ip têm como trocar?",
        "data": "15:15 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sim",
        "data": "15:16 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "trocar tem como ip",
        "data": "15:17 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa",
        "data": "15:17 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora trocar para marte que lá é bem seguro",
        "data": "15:17 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "15:17 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "como que têm um erro na linha 1350",
        "data": "15:17 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah",
        "data": "15:18 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tendo",
        "data": "15:18 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa pensei um pouco d+",
        "data": "15:18 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "ou um pouco",
        "data": "15:19 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "15:19 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "como consegui de um sorteio uma vaga para um concurso",
        "data": "15:19 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "se eu nem estive no sorteio",
        "data": "15:19 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah nossa",
        "data": "15:19 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "boa",
        "data": "15:19 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "é de 2 anos atrás",
        "data": "15:19 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que ainda dá?",
        "data": "15:19 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "da sim",
        "data": "15:20 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho que descobri uma nova biblioteca",
        "data": "15:20 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pronto",
        "data": "15:21 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora testa essa nova",
        "data": "15:21 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "!top_historico",
        "data": "15:21 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa começamo bem",
        "data": "15:21 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ue não apareceu erro",
        "data": "15:21 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "15:21 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Mensagens de nikyrie nos últimos 7 dias:",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "!top_historico",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: !top_historico, Data: 2024-05-09 18:21:33.477000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ata",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: bora testa essa nova, Data: 2024-05-09 18:21:28.222000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: pronto, Data: 2024-05-09 18:21:24.287000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: acho que descobri uma nova biblioteca, Data: 2024-05-09 18:20:13.962000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: será que ainda dá?, Data: 2024-05-09 18:19:58.527000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: é de 2 anos atrás, Data: 2024-05-09 18:19:53.170000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: ah nossa, Data: 2024-05-09 18:19:49.228000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: se eu nem estive no sorteio, Data: 2024-05-09 18:19:30.582000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: como consegui de um sorteio uma vaga para um concurso, Data: 2024-05-09 18:19:25.023000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: q, Data: 2024-05-09 18:19:12.514000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: nossa pensei um pouco d+, Data: 2024-05-09 18:18:45.063000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: ah, Data: 2024-05-09 18:18:32.352000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: como que têm um erro na linha 1350, Data: 2024-05-09 18:17:57.974000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: bora trocar para marte que lá é bem seguro, Data: 2024-05-09 18:17:37.817000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: nossa, Data: 2024-05-09 18:17:25.569000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: ip têm como trocar?, Data: 2024-05-09 18:15:57.422000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: how, Data: 2024-05-09 18:15:25.834000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: o ip caiu lá, Data: 2024-05-09 18:15:11.386000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "m",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: how, Data: 2024-05-09 18:15:06.431000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: eu realmente queria saber como o erro foi no site do awari, Data: 2024-05-09 18:14:50.421000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "PARA RO BOY",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "o bot",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: a, Data: 2024-05-09 18:14:28.300000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: pera, Data: 2024-05-09 18:14:23.085000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: tô na cadeira nop em, Data: 2024-05-09 18:14:18.757000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "Conteúdo: Aíen acentuado, Data: 2024-05-09 18:14:07.399000+00:00",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "kk",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "quase",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "boa",
        "data": "15:22 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bem ela funcionou bem k",
        "data": "15:23 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q q é isso",
        "data": "15:23 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mentir que ele tá com o fuso horário dos eua",
        "data": "15:23 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "aham",
        "data": "15:24 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "la é 00:00?",
        "data": "15:24 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bem específico de quem é as mensagens né",
        "data": "15:24 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho q no",
        "data": "15:24 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "lá no meio",
        "data": "15:24 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "tbm",
        "data": "15:24 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds o bot sobrecarregou",
        "data": "15:24 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera vou dividir o pensamento dele em 2x",
        "data": "15:24 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "assim eu multiplico o stack por 4x",
        "data": "15:25 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "= 2 bots em 1 >)",
        "data": "15:25 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "la na india é 00 agora",
        "data": "15:25 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "sério?",
        "data": "15:25 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "lá vamos nós no lendário txt",
        "data": "15:26 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera se eu converter direto para PDF é impossível perder",
        "data": "15:26 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "que pena não sei ainda em PDF k",
        "data": "15:26 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "se consegue",
        "data": "15:26 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "15:26 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "15:26 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "o ip dele caiu lá na oceania",
        "data": "15:27 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera",
        "data": "15:27 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "se o mundo é uma seed",
        "data": "15:27 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "então se eu mudar a seed onde vai cair o ip?",
        "data": "15:27 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "my god im genius",
        "data": "15:27 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:28 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "descobrimos outras dimensões",
        "data": "15:28 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "burn é lelé da cuca",
        "data": "15:28 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "15:28 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "im genius d+",
        "data": "15:28 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ou quase",
        "data": "15:29 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "deve ir",
        "data": "15:29 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "!top_historico",
        "data": "15:29 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera",
        "data": "15:29 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:29 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "paciência né",
        "data": "15:29 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "muita paciência",
        "data": "15:30 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q demora",
        "data": "15:30 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "",
        "data": "15:30 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ae",
        "data": "15:30 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "15:30 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "todas??",
        "data": "15:30 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rlx que não é vírus",
        "data": "15:30 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "15:31 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho q foi todas",
        "data": "15:31 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:31 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tô revolucionando o mundo",
        "data": "15:31 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bem tá ótimo",
        "data": "15:32 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "porém em sequência desorganizada",
        "data": "15:32 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "burn ta mais lelé do q imaginei",
        "data": "15:32 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "15:32 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "metade burn k",
        "data": "15:32 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "o edu",
        "data": "15:33 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q q eu faço?",
        "data": "15:33 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "coloco na ordem da data da sequência de cada ou registro todas?",
        "data": "15:33 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:37 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que consigo recuperar algo inrecuperável?",
        "data": "15:37 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera",
        "data": "15:37 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "15:37 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ele vê mensagens deletadas?",
        "data": "15:37 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:37 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "adoro vida de programador",
        "data": "15:38 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "se muda uma linha adquire o resultado >)",
        "data": "15:39 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "foi",
        "data": "15:39 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "deve tar indo agora",
        "data": "15:39 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mano esqueci o comando",
        "data": "15:39 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ae",
        "data": "15:39 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "!top_historico",
        "data": "15:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "agora calma",
        "data": "15:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "muita calma",
        "data": "15:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "né edu",
        "data": "15:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho que eu devia fazer ele colocar em porcentagem quando estiver completo k",
        "data": "15:40 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "",
        "data": "15:40 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "metade vai ser do bot",
        "data": "15:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será?",
        "data": "15:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "15:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkkkkkkkkkk",
        "data": "15:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será??",
        "data": "15:40 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sera",
        "data": "15:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa edu",
        "data": "15:41 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds eu não pensei nisso",
        "data": "15:41 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "net?",
        "data": "15:41 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "my god",
        "data": "15:41 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ue",
        "data": "15:41 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ae",
        "data": "15:41 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vlt",
        "data": "15:41 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "15:41 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "como você é o primeiro",
        "data": "15:42 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds tá o contrário",
        "data": "15:42 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa é um pouco difícil saber a hora em eua",
        "data": "15:43 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "4k de linha",
        "data": "15:43 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera",
        "data": "15:44 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa",
        "data": "15:44 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:45 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "imagina eu instalar vírus do próprio bot?",
        "data": "15:45 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds",
        "data": "15:45 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Mds",
        "data": "15:45 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "MDS",
        "data": "15:45 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:45 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q poco",
        "data": "15:46 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "kk",
        "data": "15:46 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "espaço bastante em kk",
        "data": "15:46 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "35k de palavras",
        "data": "15:46 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "em 7 dias",
        "data": "15:46 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "15:46 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah é a hora",
        "data": "15:47 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "caraca mds",
        "data": "15:47 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "300k",
        "data": "15:47 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "",
        "data": "15:48 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho q vou automatizar em",
        "data": "15:48 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera como",
        "data": "15:49 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vou otimizar e melhorar?",
        "data": "15:49 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "eu inverto a sequência?",
        "data": "15:49 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:49 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "precisos de sua opinion",
        "data": "15:49 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "sla",
        "data": "15:50 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "top",
        "data": "15:50 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "remover o conteúdos?",
        "data": "15:50 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "User: ele, mensagem data dela universal",
        "data": "15:50 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera ele salva imagem?",
        "data": "15:51 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nop",
        "data": "15:51 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho melhor assim né?",
        "data": "15:52 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah",
        "data": "15:52 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "já sei",
        "data": "15:52 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "User: ele, mensagem, tipodeenvio, data dela universal?",
        "data": "15:52 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "perai",
        "data": "15:53 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:53 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "o nosso tempo é de Brasília?",
        "data": "15:53 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "depende",
        "data": "15:55 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "se for é",
        "data": "15:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "é s",
        "data": "15:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "UTC-3?",
        "data": "15:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa",
        "data": "15:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "e se eu fazer ele guardar as imagens?",
        "data": "15:57 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa",
        "data": "15:57 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "15:57 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aprova?",
        "data": "15:57 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "isso ai",
        "data": "15:57 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bot tá off on",
        "data": "15:57 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "eba",
        "data": "15:57 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "agora tá on",
        "data": "15:58 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "rapa",
        "data": "15:58 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera vou por passo a passo",
        "data": "15:58 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "15:59 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "carro da justiça",
        "data": "16:00 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "manteiga sobre derretimento",
        "data": "16:00 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "qqqqqqqqqqqqqqqqqqqq",
        "data": "16:00 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "que carro passou agora mds",
        "data": "16:00 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora aplicar o que usamos na escola pela primeira vez k",
        "data": "16:02 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "regra de três",
        "data": "16:02 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pronto",
        "data": "16:03 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "!top_historico",
        "data": "16:03 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "16:03 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "agora paz né edu",
        "data": "16:03 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "vdd",
        "data": "16:03 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q paz",
        "data": "16:03 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que o bot é rápido?",
        "data": "16:03 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera eu esqueci de inverte a ordem",
        "data": "16:03 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "boa",
        "data": "16:03 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "",
        "data": "16:03 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ae",
        "data": "16:04 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "horário correto?",
        "data": "16:04 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "yes",
        "data": "16:04 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "q lanchão em",
        "data": "16:04 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vdd",
        "data": "16:05 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "mds kkkkkkkkkkkk",
        "data": "16:05 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa edu",
        "data": "16:05 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "será que é poco?",
        "data": "16:06 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa",
        "data": "16:06 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "imagina quanto erro gramatical",
        "data": "16:06 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pera",
        "data": "16:08 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "e se eu fazer ele mostrar as top 10 palavras mais utilizadas?",
        "data": "16:08 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "16:08 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nosso bot tá crescendo né",
        "data": "16:08 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q q será que é a definição de palavra?",
        "data": "16:10 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "palavra = diferente de uma letra, aceita gramaticalmente?",
        "data": "16:11 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "adoro quando sou destruído por um único erro",
        "data": "16:16 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "!top_mensagens",
        "data": "16:16 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "não deu erro",
        "data": "16:16 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tá indo",
        "data": "16:16 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ">)",
        "data": "16:16 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho q devia tar indo",
        "data": "16:16 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ae",
        "data": "16:17 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa",
        "data": "16:17 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "kkkkkkkkkkkk",
        "data": "16:17 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "a vírgula ganho de tudo",
        "data": "16:17 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nossa um emoji",
        "data": "16:17 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "16:17 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "esperava essa? kkkkkk",
        "data": "16:17 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vei a vírgula kkkkkkkk",
        "data": "16:18 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "vírgula pro d+",
        "data": "16:18 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "que bom que ele pegou os emojis tbm (não fazia a mínima ideia que isso também acontecia k)",
        "data": "16:19 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "caraca a vírgula humilhou todo mundo k",
        "data": "16:22 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bora agora para todas",
        "data": "16:23 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Caraca olha o que tô fazendo",
        "data": "16:24 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "Contando as mensagens e as armazenando na própria base de dados do bot e após isso ele irá dessa base de dados contar todas e classificá-las k",
        "data": "16:24 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "é pra ir",
        "data": "16:31 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "!top_mensagens",
        "data": "16:31 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "não deu erro",
        "data": "16:32 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tá indo >)",
        "data": "16:32 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "",
        "data": "16:32 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "16:32 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "foi",
        "data": "16:32 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "foi mesmo em",
        "data": "16:32 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "10 linah",
        "data": "16:32 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "acho que as top 1000 tá bom né?",
        "data": "16:33 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "!top_mensagens",
        "data": "16:34 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "não deu erro",
        "data": "16:34 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "tá indo >)",
        "data": "16:34 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "",
        "data": "16:34 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "16:34 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ele também pega símbolos;0",
        "data": "16:35 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "dá para saber que é o idro só por 4 palavras k",
        "data": "16:36 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "olha tem alguma coisa esquisita aq",
        "data": "16:37 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510>",
        "data": "16:37 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "se não acha?",
        "data": "16:37 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ah",
        "data": "16:40 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ele tá contando a frequência inteira de mensagens não em vez de palavras individuais",
        "data": "16:41 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aaaaaaaaaaaaaa",
        "data": "16:41 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q moleza",
        "data": "16:41 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "só dividir o conteúdo por palavras e ez",
        "data": "16:41 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "pronto",
        "data": "16:43 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "!top_mensagens",
        "data": "16:43 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "sem ero",
        "data": "16:43 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "e foi >>)",
        "data": "16:43 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "",
        "data": "16:44 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "ae",
        "data": "16:44 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "16:44 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "fi",
        "data": "16:44 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "foi*",
        "data": "16:44 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "<@674267691627839510> qual será a idro em",
        "data": "16:44 de 09/05/2024"
    },
    {
        "user": "tere_.",
        "mensagem": "qual",
        "data": "16:44 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "nem eu sei k",
        "data": "16:44 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "bastante em",
        "data": "16:45 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "hm",
        "data": "16:53 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "deve ir agora",
        "data": "16:53 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "!top_mensagens",
        "data": "16:53 de 09/05/2024"
    },
    {
        "user": "TemporalBot#7948",
        "mensagem": "",
        "data": "16:54 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": ";0",
        "data": "16:54 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "foi",
        "data": "16:54 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "de apenas 1000 delas para todas que virão >)",
        "data": "16:54 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "aliás isso tudo é de apenas 03 k",
        "data": "16:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "depois",
        "data": "16:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "q",
        "data": "16:55 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "deve tar indo",
        "data": "17:04 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "magina",
        "data": "17:04 de 09/05/2024"
    },
    {
        "user": "nikyrie",
        "mensagem": "!top_historico",
        "data": "17:04 de 09/05/2024"
    }
]
const container = document.getElementById('mensagens');
let lastUser = null;
let lastDiv = null;

dados.forEach(dado => {
    if (dado.user !== lastUser) {
        const div = document.createElement('div');
        div.classList.add('mensagem');
        div.innerHTML = `<p class="user">${dado.user} <span class="data">Data: ${dado.data}</span></p>
        <p>${dado.mensagem}</p>`;
        container.appendChild(div);
        lastUser = dado.user;
        lastDiv = div;
    } else {
        const p = document.createElement('p');
        p.innerHTML = `${dado.mensagem}`;
        lastDiv.appendChild(p);
    }
});